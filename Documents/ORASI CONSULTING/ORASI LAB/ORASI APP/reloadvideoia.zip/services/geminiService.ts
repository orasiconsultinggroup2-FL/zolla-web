// Fix: Import Modality for Live API config.
import { GoogleGenAI, Type, LiveSession, LiveServerMessage, Modality } from "@google/genai";
import { AnalysisResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    overallSummary: { type: Type.STRING, description: "A concise overall summary of the video's potential and key areas for improvement." },
    thematicInterest: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the interest of the video's theme." },
        feedback: { type: Type.STRING, description: "Detailed feedback on the theme's appeal and relevance." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Suggestions to improve the theme." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
    hook: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the effectiveness of the video's hook." },
        feedback: { type: Type.STRING, description: "Analysis of the first few seconds and its ability to grab attention." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Actionable tips for a stronger hook." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
    contentStructure: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the video's structure and flow." },
        feedback: { type: Type.STRING, description: "Feedback on the organization and clarity of the content." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Ideas for better structuring and pacing." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
    editingQuality: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the technical quality of the editing." },
        feedback: { type: Type.STRING, description: "Comments on cuts, transitions, audio quality, and visuals from the provided frames." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Technical editing tips to enhance quality." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
    narrativePace: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the video's pacing and rhythm." },
        feedback: { type: Type.STRING, description: "Analysis of whether the pace is engaging, too fast, or too slow." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Ways to adjust the narrative rhythm for better engagement." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
    audienceRetention: {
      type: Type.OBJECT,
      properties: {
        rating: { type: Type.INTEGER, description: "Rating from 1-10 on the video's potential for audience retention." },
        feedback: { type: Type.STRING, description: "Identifies points where viewers might drop off and why." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Strategies to keep viewers watching until the end." }
      },
      required: ["rating", "feedback", "suggestions"],
    },
  },
  required: ["overallSummary", "thematicInterest", "hook", "contentStructure", "editingQuality", "narrativePace", "audienceRetention"]
};


export const analyzeVideo = async (frames: string[]): Promise<AnalysisResult> => {
  try {
    const prompt = `Analyze the following sequence of video frames. Act as an expert video content strategist. Provide a detailed, constructive analysis based on current social media trends. Evaluate these key points: thematic interest, hook (initial frames), content structure, editing quality (based on visual cues), narrative pace, and audience retention strategies. Your feedback must be clear, actionable, and formatted as a JSON object.`;
    
    const imageParts = frames.map(frame => ({
      inlineData: {
        mimeType: 'image/jpeg',
        data: frame,
      }
    }));
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: { parts: [{ text: prompt }, ...imageParts] },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      }
    });

    const text = response.text.trim();
    return JSON.parse(text);
  } catch (error) {
    console.error("Error analyzing video:", error);
    throw new Error("Failed to get analysis from Gemini API.");
  }
};

export const startTranscriptionSession = (callbacks: {
    onMessage: (message: LiveServerMessage) => void;
    onError: (error: ErrorEvent) => void;
    onClose: (event: CloseEvent) => void;
    onOpen: () => void;
}): Promise<LiveSession> => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
            onopen: callbacks.onOpen,
            onmessage: callbacks.onMessage,
            onerror: callbacks.onError,
            onclose: callbacks.onClose,
        },
        config: {
            // Fix: Use Modality.AUDIO enum instead of a string for responseModalities.
            responseModalities: [Modality.AUDIO], // Must be an array
            inputAudioTranscription: {},
        },
    });
};