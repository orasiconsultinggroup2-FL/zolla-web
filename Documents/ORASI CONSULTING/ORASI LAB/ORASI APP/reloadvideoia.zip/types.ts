
export interface AnalysisPoint {
  rating: number;
  feedback: string;
  suggestions: string[];
}

export interface AnalysisResult {
  thematicInterest: AnalysisPoint;
  hook: AnalysisPoint;
  contentStructure: AnalysisPoint;
  editingQuality: AnalysisPoint;
  narrativePace: AnalysisPoint;
  audienceRetention: AnalysisPoint;
  overallSummary: string;
}

export type AppTab = 'video' | 'audio';
