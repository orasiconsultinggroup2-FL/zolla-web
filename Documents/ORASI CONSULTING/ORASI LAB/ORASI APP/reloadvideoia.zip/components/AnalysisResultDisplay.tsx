
import React from 'react';
import { AnalysisResult, AnalysisPoint } from '../types';

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.293 2.293a1 1 0 010 1.414L10 16l-4 4-4-4 5.293-5.293a1 1 0 011.414 0L10 12h3m-3 7l2.293-2.293a1 1 0 011.414 0L17 21m-4-4l-2.293-2.293a1 1 0 00-1.414 0L6 18h3" /></svg>
);
const LightBulbIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
);
const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);


const RatingMeter: React.FC<{ rating: number }> = ({ rating }) => {
    const percentage = rating * 10;
    let colorClass = 'bg-red-500';
    if (percentage > 70) {
        colorClass = 'bg-green-500';
    } else if (percentage > 40) {
        colorClass = 'bg-yellow-500';
    }

    return (
        <div className="w-full bg-gray-700 rounded-full h-2.5 my-2">
            <div className={`${colorClass} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
        </div>
    );
};

const AnalysisCard: React.FC<{ title: string; data: AnalysisPoint }> = ({ title, data }) => {
    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg transform hover:-translate-y-1 transition-transform duration-300">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-xl font-bold text-indigo-400">{title}</h3>
              <span className="text-2xl font-black text-white">{data.rating}<span className="text-sm font-light text-gray-400">/10</span></span>
            </div>
            <RatingMeter rating={data.rating} />
            <p className="text-gray-300 mt-4 mb-4 text-sm">{data.feedback}</p>
            <div>
                <h4 className="font-semibold text-gray-100 flex items-center mb-2"><LightBulbIcon className="w-5 h-5 mr-2 text-yellow-400"/>Suggestions:</h4>
                <ul className="list-none space-y-2">
                    {data.suggestions.map((suggestion, index) => (
                        <li key={index} className="flex items-start text-sm text-gray-400">
                           <CheckCircleIcon className="w-4 h-4 mr-2 text-green-500 flex-shrink-0 mt-0.5"/>
                           <span>{suggestion}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

interface AnalysisResultDisplayProps {
    result: AnalysisResult;
}

const AnalysisResultDisplay: React.FC<AnalysisResultDisplayProps> = ({ result }) => {
  const analysisPoints = [
    { title: "Thematic Interest", data: result.thematicInterest },
    { title: "Hook", data: result.hook },
    { title: "Content Structure", data: result.contentStructure },
    { title: "Editing Quality", data: result.editingQuality },
    { title: "Narrative Pace", data: result.narrativePace },
    { title: "Audience Retention", data: result.audienceRetention },
  ];

  return (
    <div className="space-y-8">
       <div className="bg-gray-800/50 p-6 rounded-lg shadow-lg border border-indigo-500/30">
        <h3 className="text-xl font-bold text-indigo-400 flex items-center mb-2"><SparklesIcon className="w-6 h-6 mr-2"/>Overall Summary</h3>
        <p className="text-gray-300">{result.overallSummary}</p>
       </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {analysisPoints.map(point => <AnalysisCard key={point.title} title={point.title} data={point.data} />)}
      </div>
    </div>
  );
};

export default AnalysisResultDisplay;
