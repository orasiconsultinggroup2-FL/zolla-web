
import React, { useState, useRef, useCallback } from 'react';
import { analyzeVideo } from '../services/geminiService';
import { AnalysisResult } from '../types';
import Loader from './Loader';
import AnalysisResultDisplay from './AnalysisResultDisplay';

const UploadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
);


const VideoAnalyzer: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const extractFrames = useCallback(async (videoElement: HTMLVideoElement, canvasElement: HTMLCanvasElement): Promise<string[]> => {
    return new Promise(async (resolve) => {
      const frames: string[] = [];
      const ctx = canvasElement.getContext('2d');
      if (!ctx) {
        setError("Could not get canvas context.");
        resolve([]);
        return;
      }
      
      const MAX_FRAMES = 25;
      const duration = videoElement.duration;
      const interval = duration / MAX_FRAMES;

      canvasElement.width = videoElement.videoWidth;
      canvasElement.height = videoElement.videoHeight;
      
      let processedFrames = 0;

      const captureFrame = async (time: number) => {
        return new Promise<void>((resolveSeek) => {
          videoElement.currentTime = time;
          videoElement.onseeked = () => {
            ctx.drawImage(videoElement, 0, 0, videoElement.videoWidth, videoElement.videoHeight);
            const frameDataUrl = canvasElement.toDataURL('image/jpeg', 0.8);
            frames.push(frameDataUrl.split(',')[1]);
            processedFrames++;
            setProgress(Math.round((processedFrames / MAX_FRAMES) * 100));
            resolveSeek();
          };
        });
      };

      for (let i = 0; i < MAX_FRAMES; i++) {
        await captureFrame(i * interval);
      }
      
      resolve(frames);
    });
  }, []);
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      setAnalysisResult(null);
      setError(null);
      setProgress(0);
    } else {
      setError("Please select a valid video file.");
    }
  };

  const handleAnalyzeClick = useCallback(async () => {
    if (!videoFile || !videoRef.current || !canvasRef.current) return;

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setProgress(0);
    
    videoRef.current.src = URL.createObjectURL(videoFile);
    
    videoRef.current.onloadedmetadata = async () => {
      try {
        const frames = await extractFrames(videoRef.current!, canvasRef.current!);
        if (frames.length > 0) {
          const result = await analyzeVideo(frames);
          setAnalysisResult(result);
        } else {
            setError("Could not extract frames from the video.")
        }
      } catch (err: any) {
        setError(err.message || 'An unexpected error occurred during analysis.');
      } finally {
        setIsLoading(false);
        setProgress(100);
      }
    };

    videoRef.current.onerror = () => {
        setIsLoading(false);
        setError("Error loading video file. It may be corrupt or in an unsupported format.");
    }

  }, [videoFile, extractFrames]);

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if(isLoading) return;

    const file = event.dataTransfer.files?.[0];
    if (file && file.type.startsWith('video/')) {
        setVideoFile(file);
        setAnalysisResult(null);
        setError(null);
        setProgress(0);
    } else {
        setError("Please drop a valid video file.");
    }
  }

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div 
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => fileInputRef.current?.click()}
        className="bg-gray-800 border-2 border-dashed border-gray-600 rounded-lg p-8 text-center cursor-pointer hover:border-indigo-500 hover:bg-gray-700/50 transition-colors"
      >
        <input
          type="file"
          accept="video/*"
          onChange={handleFileChange}
          className="hidden"
          ref={fileInputRef}
          disabled={isLoading}
        />
        <UploadIcon className="w-12 h-12 mx-auto text-gray-500"/>
        {videoFile ? (
            <p className="mt-4 text-lg text-white">{videoFile.name}</p>
        ) : (
            <p className="mt-4 text-lg text-gray-400">Drop your video here, or click to browse</p>
        )}
        <p className="text-sm text-gray-500 mt-1">MP4, MOV, WebM, etc.</p>
      </div>

      {videoFile && (
        <div className="text-center mt-6">
          <button
            onClick={handleAnalyzeClick}
            disabled={isLoading}
            className="bg-indigo-600 text-white font-bold py-3 px-8 rounded-full hover:bg-indigo-700 transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed transform hover:scale-105 shadow-lg"
          >
            {isLoading ? 'Analyzing...' : 'Analyze Video'}
          </button>
        </div>
      )}

      {isLoading && (
        <div className="mt-8">
            <p className="text-center text-indigo-400 mb-2">Extracting frames: {progress}%</p>
            <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            { progress === 100 && <p className="text-center text-indigo-400 mt-4">Frames extracted. Sending to AI for analysis...</p>}
            <Loader />
        </div>
      )}

      {error && <p className="mt-6 text-center text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      
      {analysisResult && !isLoading && (
        <div className="mt-10">
          <h2 className="text-3xl font-bold text-center mb-6 text-white">Analysis Results</h2>
          <AnalysisResultDisplay result={analysisResult} />
        </div>
      )}

      <video ref={videoRef} style={{ display: 'none' }}></video>
      <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
    </div>
  );
};

export default VideoAnalyzer;
