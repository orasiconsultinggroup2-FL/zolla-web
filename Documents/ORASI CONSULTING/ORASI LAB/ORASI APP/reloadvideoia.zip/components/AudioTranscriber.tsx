import React, { useState, useRef, useEffect, useCallback } from 'react';
import { LiveSession, LiveServerMessage } from '@google/genai';
import { startTranscriptionSession } from '../services/geminiService';

const MicIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
);

const StopIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12v0a9 9 0 01-9 9s-9-4.03-9-9 4.03-9 9-9v0a9 9 0 019 9z" /><path d="M9 9h6v6H9z"/></svg>
);

function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

const AudioTranscriber: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState('Idle. Click record to start.');

  const sessionRef = useRef<LiveSession | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const stopRecordingResources = useCallback(() => {
    if (sessionRef.current) {
        sessionRef.current.close();
        sessionRef.current = null;
    }
    if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
    }
    if (scriptProcessorRef.current) {
        scriptProcessorRef.current.disconnect();
        scriptProcessorRef.current = null;
    }
    if (mediaStreamSourceRef.current) {
        mediaStreamSourceRef.current.disconnect();
        mediaStreamSourceRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
        audioContextRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      stopRecordingResources();
    };
  }, [stopRecordingResources]);

  const handleStartRecording = async () => {
    if (isRecording) return;
    setIsRecording(true);
    setError(null);
    setTranscription('');
    setStatus('Requesting microphone access...');

    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      setStatus('Connecting to transcription service...');

      const sessionPromise = startTranscriptionSession({
        onOpen: () => {
          setStatus('Connected. Listening for audio...');
          // Fix: Property 'webkitAudioContext' does not exist on type 'Window & typeof globalThis'. Cast window to any to bypass type check for vendor-prefixed API.
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
          mediaStreamSourceRef.current = audioContextRef.current.createMediaStreamSource(streamRef.current!);
          scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
          
          scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
              int16[i] = inputData[i] * 32768;
            }
            const pcmBlob = {
              data: encode(new Uint8Array(int16.buffer)),
              mimeType: 'audio/pcm;rate=16000',
            };
            sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
          };
          
          mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
          scriptProcessorRef.current.connect(audioContextRef.current.destination);
        },
        onMessage: (message: LiveServerMessage) => {
          if (message.serverContent?.inputTranscription) {
            const text = message.serverContent.inputTranscription.text;
            setTranscription(prev => prev + text);
          }
        },
        onError: (e: ErrorEvent) => {
          console.error("Session error:", e);
          setError("A session error occurred. Please try again.");
          setStatus('Error. Please try again.');
          stopRecordingResources();
          setIsRecording(false);
        },
        onClose: () => {
          setStatus('Session closed.');
        },
      });
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Error starting recording:", err);
      setError("Could not access microphone. Please check your browser permissions.");
      setStatus('Error accessing microphone.');
      setIsRecording(false);
    }
  };

  const handleStopRecording = () => {
    if (!isRecording) return;
    setIsRecording(false);
    setStatus('Recording stopped. Finalizing transcription...');
    stopRecordingResources();
    setStatus('Idle. Click record to start.');
  };
  
  return (
    <div className="max-w-3xl mx-auto text-center">
      <h2 className="text-2xl font-bold mb-2">Live Audio Transcription</h2>
      <p className="text-gray-400 mb-6">Click the button and start speaking. Your words will be transcribed in real-time.</p>
      
      <div className="mb-6">
        <button
          onClick={isRecording ? handleStopRecording : handleStartRecording}
          className={`relative inline-flex items-center justify-center w-24 h-24 rounded-full transition-all duration-300 shadow-lg
            ${isRecording ? 'bg-red-600 hover:bg-red-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}
        >
          {isRecording ? <StopIcon className="w-10 h-10 text-white" /> : <MicIcon className="w-10 h-10 text-white" />}
          {isRecording && <span className="absolute h-full w-full rounded-full bg-red-500 animate-ping opacity-75"></span>}
        </button>
      </div>

      <p className="text-indigo-400 h-6 mb-4">{status}</p>

      {error && <p className="text-red-400 bg-red-900/50 p-3 rounded-lg my-4">{error}</p>}
      
      <div className="w-full bg-gray-800 rounded-lg p-6 text-left min-h-[200px] border border-gray-700 shadow-inner">
        <p className="text-lg text-gray-200 whitespace-pre-wrap">
          {transcription || <span className="text-gray-500">Transcription will appear here...</span>}
        </p>
      </div>
    </div>
  );
};

export default AudioTranscriber;