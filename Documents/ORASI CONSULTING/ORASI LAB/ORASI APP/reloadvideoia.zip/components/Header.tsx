
import React from 'react';

const FilmIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
  </svg>
);

const Header: React.FC = () => {
  return (
    <header className="bg-gray-800/50 backdrop-blur-sm shadow-lg p-4 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-center">
        <FilmIcon className="w-8 h-8 text-indigo-400 mr-3" />
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider">ReloadvideoIA</h1>
          <p className="text-sm text-gray-400">Vitalize Your Videos with AI-Powered Insights</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
