
import React, { useState } from 'react';
import { AppTab } from './types';
import Header from './components/Header';
import Tabs from './components/Tabs';
import VideoAnalyzer from './components/VideoAnalyzer';
import AudioTranscriber from './components/AudioTranscriber';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>('video');

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
        <div className="mt-8">
          {activeTab === 'video' && <VideoAnalyzer />}
          {activeTab === 'audio' && <AudioTranscriber />}
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;
