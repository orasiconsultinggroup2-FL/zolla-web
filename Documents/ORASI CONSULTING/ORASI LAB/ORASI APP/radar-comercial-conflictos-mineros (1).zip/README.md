# ORASI Lab | Radar Comercial de Conflictos Mineros

**Sistema Operativo RevOps + Data Engineering + Sales Ops**  
Marca: ORASI Lab (ícono esférico + texto)

---

## 🚀 IMPLEMENTACIÓN RÁPIDA

### **Paso 1: Acceder al Sistema**
1. Descargar los 2 archivos: `index.html` y `app.js`
2. Colocarlos en la misma carpeta
3. Abrir `index.html` en cualquier navegador moderno (Chrome, Firefox, Edge)

### **Paso 2: Cargar Datos Iniciales**
- Opción A: Click en "Importar" → "Cargar Datos de Ejemplo" (10 empresas mineras reales)
- Opción B: Subir tu propio CSV con formato específico

### **Paso 3: Explorar**
- **Radar**: Visualiza todas las cuentas con filtros
- **Semanal**: Revisa Top 10 Tier 1
- **Config**: Ajusta plantillas y parámetros

---

## 📊 ESTRUCTURA DE DATOS

### **Archivo CSV Requerido**
```
Empresa,Caso,Departamento,Provincia,Distrito,Estado,Tipo,Fuente primaria,Notas,URL
Minera XYZ,Conflicto comunal,Lima,Huarochirí,San Mateo,Activo,Ambiental,OEFA,Requerimientos,https://...
```

**Columnas Obligatorias:**
- Empresa, Caso, Departamento, Provincia, Distrito
- Estado, Tipo, Fuente primaria

**Columnas Opcionales:**
- Notas, URL

---

## 🎯 FLUJO DE TRABAJO

### **1. Ingesta de Datos (Semanal/Mensual)**
```
[Excel/CSV] → [Importar] → [Validación] → [Normalización] → [Scoring] → [Asignación Tier]
```

### **2. Análisis y Priorización**
```
[Filtros] → [Ranking] → [Tier 1: Top 10] → [Generación de Tareas]
```

### **3. Ejecución Comercial**
```
[Tier 1] → [4 Acciones] → [Log] → [Seguimiento]
```

---

## 🎲 FÓRMULA DE SCORING (Transparente)

### **Cálculo Manual para Verificación**

**Empresa Ejemplo: Minera XYZ**
- **Urgencia (30%)**: Estado = Activo (15 pts) + Señal hace 15 días (15 pts) = **30/30**
- **Exposición (20%)**: Severidad 5 (20 pts) + Bloqueo (5 pts) = **25/20** (capped)
- **Complejidad (20%)**: 3 comunidades (8 pts) + 2 autoridades (7 pts) + Mesa (5 pts) = **20/20**
- **Capacidad (15%)**: Empresa Grande = **15/15**
- **Accesibilidad (15%)**: 3 canales verificados = **15/15**

**Score Total**: (30×100/30)×0.30 + (20×100/20)×0.20 + (20×100/20)×0.20 + (15×100/15)×0.15 + (15×100/15)×0.15 = **100**

**Tier**: Tier 1 (≥75)

---

## 📧 PLANTILLAS DE MENSAJAS

### **Plantilla 1: Correo Institucional**
```
Asunto: Análisis de riesgo social | ORASI Lab - Sector Minero

Estimado/a [Nombre Contacto],

En ORASI Lab, monitoreamos indicadores de riesgo social. Identificamos que [Empresa] gestiona [N°] casos en [región].

Nuestro análisis, basado en fuentes públicas verificables (OEFA, Defensoría), indica oportunidades de mejora en gestión comunitaria y cumplimiento regulatorio.

¿Tienen 20 minutos para revisar un one-pager con hallazgos específicos?

Saludos,
[Tu nombre]
ORASI Lab - RevOps para Minería Responsable
```

### **Plantilla 2: LinkedIn**
```
Gracias por conectar, [Nombre].

Vi que [Empresa] opera en [región]. Nuestro radar independiente detectó [N°] señales de conflictos sociales (fuentes: Defensoría/OEFA).

No es una venta, es un análisis con trazabilidad completa. ¿Te interesa un one-pager?

Saludos,
[Tu nombre]
ORASI Lab
```

---

## 🛡️ REGLAS DE CUMPLIMIENTO

### **✅ PERMITIDO**
- Datos corporativos verificados (web, teléfonos públicos, correos institucionales)
- Fuentes públicas (OEFA, Defensoría, Prensa, Ministerios)
- Trazabilidad completa (Fuente + Fecha + URL)

### **❌ PROHIBIDO**
- ❌ Números de celular personales
- ❌ DNI o datos personales
- ❌ Nombres de comuneros o líderes
- ❌ WhatsApp sin consentimiento
- ❌ Cold calling a números personales

### **⚠️ RECOMENDADO**
- Contacto institucional primero
- Ofrecer valor (análisis) antes de venta
- Respetar "No contactar" si empresa lo solicita

---

## 🔄 AUTOMATIZACIÓN

### **Programación (Lunes 9:00 AM)**
1. Click "Activar Programación" en Tab Semanal
2. El sistema genera tareas para Tier 1 automáticamente
3. Crea secuencia de 4 acciones por cuenta

### **Simulación**
- En desarrollo: Click "Generar Tareas Ahora"
- En producción: Usar `setInterval` o cron job

---

## 📋 CHECKLIST GO-LIVE

### **Pre-Producción**
- [ ] Cargar dataset real (mínimo 20 empresas)
- [ ] Validar cálculo manual de 5 scores
- [ ] Probar importación CSV
- [ ] Verificar exportación CSV
- [ ] Confirmar filtros funcionan
- [ ] Probar modal de cuenta (todas las pestañas)
- [ ] Generar tareas manualmente
- [ ] Verificar logs de auditoría

### **Producción**
- [ ] Backup de datos (exportar CSV semanal)
- [ ] Documentar proceso de actualización
- [ ] Capacitar usuario final
- [ ] Definir responsable de actualización
- [ ] Establecer SLA de actualización (mensual)

---

## 📈 MÉTRICAS DE ÉXITO

| Métrica | Target | Medición |
|---------|--------|----------|
| Data Quality | 100% | % filas con fuente+fecha+url |
| Scoring Accuracy | ±5% | Validación manual |
| Tier 1 Coverage | 100% | Tareas generadas |
| User Experience | <3 clics | Importar datos |
| Performance | <2s | Recalcular 1000 registros |

---

## 🔧 SOLUCIÓN DE PROBLEMAS

### **Problema: "No se importan datos"**
**Solución**: Verificar formato CSV (comas, encoding UTF-8)

### **Problema: "Scores bajos"**
**Solución**: Revisar que todas las empresas tengan casos y señales

### **Problema: "No hay Tier 1"**
**Solución**: Importar datos con severidad alta (4-5) y estado "Activo"

### **Problema: "Datos no persisten"**
**Solución**: El navegador usa localStorage. Limpiar caché puede borrar datos. Exportar CSV regularmente.

---

## 📚 DICCIONARIO DE DATOS COMPLETO

Ver sección "DICCIONARIO DE DATOS" en el código fuente (app.js) para campos completos.

---

## ⚠️ LIMITACIONES Y SUPUESTOS

### **Supuestos**
1. **Almacenamiento**: Usa localStorage del navegador (límite ~5-10MB)
2. **Automatización**: Requiere navegador abierto para programación
3. **Multi-usuario**: Solo un usuario a la vez (sin sincronización)
4. **Escalabilidad**: Ideal para 100-500 empresas (no para miles)

### **Alternativas para Escalar**
- **Backend**: Node.js + PostgreSQL + Bull Queue para tareas
- **Cloud**: AWS Lambda + DynamoDB + EventBridge
- **Multi-tenant**: Auth0 + base de datos por usuario

---

## 🎓 EJEMPLOS REALES

### **Ejemplo 1: Tier 1 (Score 95)**
- Empresa: Minera Las Bambas
- Casos: 3 activos en Cusco
- Severidad: 5 (bloqueo de vías)
- Canales: 3 verificados
- **Acción**: Iniciar cadencia completa

### **Ejemplo 2: Tier 2 (Score 60)**
- Empresa: Minera Yanacocha
- Casos: 1 latente en La Libertad
- Severidad: 3
- Canales: 2 verificados
- **Acción**: Monitorear mensualmente

---

## 📞 SOPORTE

Para dudas técnicas o personalización:
- Revisar código fuente (comentarios en app.js)
- Adaptar fórmulas según necesidades específicas
- Modificar plantillas en Tab Config

---

**Versión**: 1.0.0  
**Fecha**: 2024  
**Desarrollado por**: ORASI Lab - RevOps + Data Engineering