// ORASI Lab | Radar Comercial de Conflictos Mineros
// Sistema Operativo RevOps + Data Engineering + Sales Ops

// ==================== GLOBAL STATE ====================
let db = {
    empresas: [],
    casos: [],
    señales: [],
    contactos: [],
    tareas: [],
    logs: [],
    templates: {
        email: `Estimado/a [Nombre Contacto o "Equipo de Gestión"],\n\nEn ORASI Lab, monitoreamos indicadores de riesgo social en el sector minero peruano. Identificamos que [Empresa] gestiona actualmente [N°] casos relacionados a [tipo_conflicto] en [ubicación].\n\nNuestro análisis independiente, basado en fuentes públicas verificables (OEFA, Defensoría del Pueblo, prensa regional), indica oportunidades de mejora en:\n- Gestión de relaciones comunitarias\n- Cumplimiento regulatorio ambiental-social\n- Protocolos de comunicación con actores locales\n\nNuestra metodología de auditoría RevOps aplicada a riesgo social permite:\n1. Trazabilidad completa de fuentes (con URLs verificables)\n2. Priorización objetiva de casos (scoring transparente)\n3. Roadmap de mitigación con ROI medible\n\n¿Tienen 20 minutos esta semana para revisar un one-pager con hallazgos específicos para su operación?\n\nSaludos cordiales,\n[Tu nombre]\nORASI Lab - RevOps para Minería Responsable\n[Contacto institucional verificado]`,
        linkedin: `Gracias por conectar, [Nombre].\n\nVi que [Empresa] opera en [región]. Nuestro radar independiente detectó [N°] señales relacionadas a conflictos sociales (fuentes: Defensoría/OEFA).\n\nNo es una venta, es un análisis de riesgo con trazabilidad completa. ¿Te interesa un one-pager para compartir con tu equipo?\n\nSaludos,\n[Tu nombre]\nORASI Lab`,
        onepager: `ORASI LAB | ANÁLISIS DE RIESGO SOCIAL\n\nEmpresa: [Razón Social]\nFecha: [Fecha análisis]\nFuentes verificadas: [N°] URLs\n\nRESUMEN EJECUTIVO\n- Casos activos: [N°]\n- Severidad máxima: [1-5]\n- Última señal: [días] días\n- Score ORASI: [0-100]\n\nHALLAZGOS CLAVE\n1. [Hallazgo 1 con fuente URL]\n2. [Hallazgo 2 con fuente URL]\n3. [Hallazgo 3 con fuente URL]\n\nOPORTUNIDAD\nNuestro servicio de [servicio específico] puede ayudar a:\n- [Beneficio 1]\n- [Beneficio 2]\n\nPROPUESTA DE REUNIÓN\n20 minutos para revisar metodología y casos comparables.\n\n[Tu contacto institucional verificado]`
    },
    config: {
        autoSchedule: false,
        lastExecution: null,
        nextExecution: null
    }
};

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    updateNextExecutionDisplay();
    showTab('radar');
    renderRadarTable();
    populateFilters();
    renderSemanalTable();
    loadTemplates();
});

// ==================== STORAGE ====================
function saveToStorage() {
    try {
        localStorage.setItem('orasiLabDB', JSON.stringify(db));
        console.log('✅ Datos guardados en localStorage');
    } catch (e) {
        console.error('❌ Error al guardar:', e);
        alert('Error al guardar datos. El almacenamiento local puede estar lleno.');
    }
}

function loadFromStorage() {
    try {
        const stored = localStorage.getItem('orasiLabDB');
        if (stored) {
            db = JSON.parse(stored);
            console.log('✅ Datos cargados desde localStorage');
        }
    } catch (e) {
        console.error('❌ Error al cargar:', e);
    }
}

// ==================== TAB NAVIGATION ====================
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
        tab.style.display = 'none';
    });
    
    // Show selected tab
    const selectedTab = document.getElementById(`tab-${tabName}`);
    if (selectedTab) {
        selectedTab.classList.add('active');
        selectedTab.style.display = 'block';
    }
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('text-blue-600', 'bg-blue-50');
    });
    const activeBtn = document.getElementById(`nav-${tabName}`);
    if (activeBtn) {
        activeBtn.classList.add('text-blue-600', 'bg-blue-50');
    }
    
    // Refresh content based on tab
    if (tabName === 'radar') {
        renderRadarTable();
        populateFilters();
    } else if (tabName === 'semanal') {
        renderSemanalTable();
        updateNextExecutionDisplay();
    } else if (tabName === 'settings') {
        loadTemplates();
    }
}

// ==================== DATA IMPORT ====================
function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const text = e.target.result;
        processCSV(text);
    };
    reader.readAsText(file);
}

function processCSV(csvText) {
    const lines = csvText.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
        alert('Archivo CSV vacío o inválido');
        return;
    }
    
    const headers = lines[0].split(',').map(h => h.trim());
    const requiredHeaders = ['Empresa', 'Caso', 'Departamento', 'Provincia', 'Distrito', 'Estado', 'Tipo', 'Fuente primaria'];
    
    // Validar headers
    const missing = requiredHeaders.filter(h => !headers.includes(h));
    if (missing.length > 0) {
        alert(`Faltan columnas requeridas: ${missing.join(', ')}`);
        return;
    }
    
    let successCount = 0;
    let errorCount = 0;
    const messages = [];
    
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        if (values.length < headers.length) continue;
        
        const row = {};
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });
        
        try {
            processRow(row);
            successCount++;
        } catch (e) {
            errorCount++;
            messages.push(`❌ Fila ${i}: ${e.message}`);
        }
    }
    
    saveToStorage();
    showValidationResults(successCount, errorCount, messages);
    renderRadarTable();
}

function processRow(row) {
    // Validaciones
    if (!row['Empresa'] || !row['Caso']) {
        throw new Error('Empresa y Caso son obligatorios');
    }
    
    if (!row['Fuente primaria']) {
        throw new Error('Fuente primaria es obligatoria');
    }
    
    // Normalizar empresa
    const empresaNormalizada = row['Empresa'].toUpperCase().trim();
    
    // Buscar o crear empresa
    let empresa = db.empresas.find(e => 
        e.razon_social_normalizada === empresaNormalizada || 
        (row['RUC'] && e.ruc === row['RUC'])
    );
    
    if (!empresa) {
        empresa = {
            account_id: Date.now() + Math.random(),
            ruc: row['RUC'] || null,
            razon_social_normalizada: empresaNormalizada,
            nombre_comercial: row['Nombre comercial'] || empresaNormalizada,
            web_oficial: row['Web'] || 'https://ejemplo.com',
            central_tel_oficial: row['Teléfono'] || '+51 01-000-0000',
            correo_institucional: row['Email'] || 'contacto@ejemplo.com',
            sector: 'Minería',
            país: 'Perú',
            región: row['Departamento'] || 'Lima',
            proyectos_uea: row['Proyectos'] || '',
            tamaño_proxy: inferirTamano(row['Tamaño']),
            última_actualización: new Date().toISOString().split('T')[0]
        };
        db.empresas.push(empresa);
    }
    
    // Crear caso
    const caso = {
        case_id: Date.now() + Math.random(),
        account_id: empresa.account_id,
        nombre_caso: row['Caso'],
        ubicación_dep: row['Departamento'],
        ubicación_prov: row['Provincia'],
        ubicación_dist: row['Distrito'],
        tipo_conflicto: row['Tipo'] || 'Social',
        estado: row['Estado'] || 'Activo',
        motivo_resumen: row['Notas'] || 'Sin detalles',
        fecha_reporte: row['Fecha'] || new Date().toISOString().split('T')[0],
        fuente_primaria: row['Fuente primaria'],
        url_fuente: row['URL'] || ''
    };
    db.casos.push(caso);
    
    // Crear señal si hay URL
    if (row['URL']) {
        const señal = {
            signal_id: Date.now() + Math.random(),
            account_id: empresa.account_id,
            tipo_señal: 'Oficial',
            severidad: inferirSeveridad(row['Estado']),
            fecha: new Date().toISOString().split('T')[0],
            resumen: row['Notas'] || caso.nombre_caso,
            url: row['URL']
        };
        db.señales.push(señal);
    }
    
    // Crear contacto institucional básico
    const contacto = {
        channel_id: Date.now() + Math.random(),
        account_id: empresa.account_id,
        tipo: 'Correo central',
        detalle: empresa.correo_institucional,
        url: '',
        verificado: 'No',
        fecha_verificación: new Date().toISOString().split('T')[0]
    };
    db.contactos.push(contacto);
    
    // Crear registro de gestión comercial
    const score = calcularScoreParaEmpresa(empresa.account_id);
    const tier = asignarTier(score);
    
    const gestion = {
        owner: 'Sin asignar',
        etapa_pipeline: 'Lead',
        score_total: score,
        tier: tier,
        próxima_acción: tier === 'Tier 1' ? 'Iniciar cadencia' : 'Monitorear',
        fecha_próxima_acción: tier === 'Tier 1' ? obtenerProximoLunes() : '',
        historial_interacciones: `Importado: ${new Date().toISOString()}\n`
    };
    
    // Guardar gestión en empresa extendida
    empresa.gestion = gestion;
}

function inferirTamano(tamañoInput) {
    if (!tamañoInput) return 'Mediana';
    const t = tamañoInput.toLowerCase();
    if (t.includes('gran') || t.includes('large')) return 'Grande';
    if (t.includes('peque') || t.includes('small')) return 'Pequeña';
    return 'Mediana';
}

function inferirSeveridad(estado) {
    const e = estado.toLowerCase();
    if (e.includes('activo') || e.includes('grave')) return 5;
    if (e.includes('latente')) return 3;
    if (e.includes('dialogo')) return 2;
    return 1;
}

// ==================== SCORING ENGINE ====================
function calcularScoreParaEmpresa(accountId) {
    const empresa = db.empresas.find(e => e.account_id === accountId);
    if (!empresa) return 0;
    
    const casos = db.casos.filter(c => c.account_id === accountId);
    const señales = db.señales.filter(s => s.account_id === accountId);
    const contactos = db.contactos.filter(c => c.account_id === accountId);
    
    // 1. URGENCIA (30 puntos)
    let urgencia = 0;
    const casoPrincipal = casos[0];
    if (casoPrincipal) {
        if (casoPrincipal.estado === 'Activo') urgencia += 15;
        else if (casoPrincipal.estado === 'Latente') urgencia += 10;
        else if (casoPrincipal.estado === 'Dialogo') urgencia += 8;
    }
    
    // Señales recientes
    if (señales.length > 0) {
        const hoy = new Date();
        const ultimaSeñal = new Date(Math.max(...señales.map(s => new Date(s.fecha))));
        const diasDiff = Math.floor((hoy - ultimaSeñal) / (1000 * 60 * 60 * 24));
        
        if (diasDiff <= 30) urgencia += 15;
        else if (diasDiff <= 90) urgencia += 8;
    }
    
    // 2. EXPOSICIÓN (20 puntos)
    let exposicion = 0;
    const maxSeveridad = señales.length > 0 ? Math.max(...señales.map(s => s.severidad)) : 2;
    exposicion += (maxSeveridad * 4);
    
    // Verificar bloqueo o violencia en notas
    const tieneBloqueo = casos.some(c => 
        c.motivo_resumen.toLowerCase().includes('bloqueo') || 
        c.motivo_resumen.toLowerCase().includes('cierre')
    );
    const tieneViolencia = casos.some(c => 
        c.motivo_resumen.toLowerCase().includes('violencia') || 
        c.motivo_resumen.toLowerCase().includes('enfrentamiento')
    );
    
    if (tieneBloqueo) exposicion += 5;
    if (tieneViolencia) exposicion += 5;
    
    // 3. COMPLEJIDAD (20 puntos)
    let complejidad = 0;
    const comunidadesUnicas = [...new Set(casos.map(c => c.ubicación_dist))];
    const numComunidades = comunidadesUnicas.length;
    
    if (numComunidades >= 3) complejidad += 8;
    else if (numComunidades >= 2) complejidad += 5;
    
    // Simular múltiples autoridades (proxy)
    const numAutoridades = Math.min(casos.length, 3);
    if (numAutoridades >= 2) complejidad += 7;
    
    const tieneMesa = casos.some(c => 
        c.motivo_resumen.toLowerCase().includes('mesa') || 
        c.motivo_resumen.toLowerCase().includes('diálogo')
    );
    if (tieneMesa) complejidad += 5;
    
    // 4. CAPACIDAD (15 puntos)
    let capacidad = 0;
    if (empresa.tamaño_proxy === 'Grande') capacidad += 15;
    else if (empresa.tamaño_proxy === 'Mediana') capacidad += 10;
    else if (empresa.tamaño_proxy === 'Pequeña') capacidad += 5;
    
    // 5. ACCESIBILIDAD (15 puntos)
    let accesibilidad = 0;
    const canalesVerificados = contactos.filter(c => c.verificado === 'Sí').length;
    
    if (canalesVerificados >= 3) accesibilidad += 15;
    else if (canalesVerificados >= 2) accesibilidad += 10;
    else if (canalesVerificados >= 1) accesibilidad += 5;
    
    // SUMA TOTAL
    const score = (urgencia * 0.30 * 100/30) + 
                  (exposicion * 0.20 * 100/20) + 
                  (complejidad * 0.20 * 100/20) + 
                  (capacidad * 0.15 * 100/15) + 
                  (accesibilidad * 0.15 * 100/15);
    
    return Math.min(Math.round(score), 100);
}

function asignarTier(score) {
    if (score >= 75) return 'Tier 1';
    if (score >= 50) return 'Tier 2';
    if (score >= 25) return 'Tier 3';
    return 'Monitoreo';
}

function recalculateAllScores() {
    db.empresas.forEach(empresa => {
        const score = calcularScoreParaEmpresa(empresa.account_id);
        const tier = asignarTier(score);
        
        if (!empresa.gestion) {
            empresa.gestion = {};
        }
        
        empresa.gestion.score_total = score;
        empresa.gestion.tier = tier;
        empresa.gestion.próxima_acción = tier === 'Tier 1' ? 'Iniciar cadencia' : 'Monitorear';
    });
    
    saveToStorage();
    alert('✅ Scores recalculados correctamente');
    renderRadarTable();
    renderSemanalTable();
}

// ==================== FILTERS & RENDER ====================
function populateFilters() {
    const regionSelect = document.getElementById('filter-region');
    if (!regionSelect) return;
    
    // Get unique regions
    const regiones = [...new Set(db.empresas.map(e => e.región))].sort();
    
    // Clear existing options except first
    regionSelect.innerHTML = '<option value="">Todas</option>';
    
    regiones.forEach(region => {
        const option = document.createElement('option');
        option.value = region;
        option.textContent = region;
        regionSelect.appendChild(option);
    });
}

function applyFilters() {
    const filters = {
        region: document.getElementById('filter-region')?.value || '',
        estado: document.getElementById('filter-estado')?.value || '',
        tipo: document.getElementById('filter-tipo')?.value || '',
        score: parseInt(document.getElementById('filter-score')?.value) || 0,
        tier: document.getElementById('filter-tier')?.value || ''
    };
    
    renderRadarTable(filters);
}

function clearFilters() {
    document.getElementById('filter-region').value = '';
    document.getElementById('filter-estado').value = '';
    document.getElementById('filter-tipo').value = '';
    document.getElementById('filter-score').value = '';
    document.getElementById('filter-tier').value = '';
    renderRadarTable();
}

function renderRadarTable(filters = {}) {
    const tbody = document.getElementById('radar-table-body');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    let empresas = db.empresas.filter(empresa => {
        // Filter by region
        if (filters.region && empresa.región !== filters.region) return false;
        
        // Filter by tier
        if (filters.tier && empresa.gestion?.tier !== filters.tier) return false;
        
        // Filter by score
        if (filters.score && (empresa.gestion?.score_total || 0) < filters.score) return false;
        
        // Filter by estado (from casos)
        if (filters.estado) {
            const casos = db.casos.filter(c => c.account_id === empresa.account_id);
            if (!casos.some(c => c.estado === filters.estado)) return false;
        }
        
        // Filter by tipo (from casos)
        if (filters.tipo) {
            const casos = db.casos.filter(c => c.account_id === empresa.account_id);
            if (!casos.some(c => c.tipo_conflicto === filters.tipo)) return false;
        }
        
        return true;
    });
    
    // Sort by score descending
    empresas.sort((a, b) => (b.gestion?.score_total || 0) - (a.gestion?.score_total || 0));
    
    if (empresas.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="px-6 py-8 text-center text-gray-500">No hay datos. Importa datos primero.</td></tr>';
        return;
    }
    
    empresas.forEach(empresa => {
        const casos = db.casos.filter(c => c.account_id === empresa.account_id);
        const estado = casos.length > 0 ? casos[0].estado : 'N/A';
        const score = empresa.gestion?.score_total || 0;
        const tier = empresa.gestion?.tier || 'N/A';
        const proximaAccion = empresa.gestion?.próxima_acción || '-';
        
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50 cursor-pointer';
        row.onclick = () => openAccountModal(empresa.account_id);
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">${empresa.razon_social_normalizada}</div>
                <div class="text-xs text-gray-500">${empresa.nombre_comercial}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${empresa.región}</td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 py-1 text-xs font-semibold rounded-full ${getEstadoColor(estado)}">${estado}</span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                        <div class="score-bar bg-blue-600 h-2 rounded-full" style="width: ${score}%"></div>
                    </div>
                    <span class="text-sm font-semibold text-gray-900">${score}</span>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 py-1 text-xs font-semibold border rounded-full ${getTierClass(tier)}">${tier}</span>
            </td>
            <td class="px-6 py-4 text-sm text-gray-500">${proximaAccion}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm">
                <button onclick="event.stopPropagation(); openAccountModal(${empresa.account_id})" class="text-blue-600 hover:text-blue-900 mr-2">Ver</button>
                <button onclick="event.stopPropagation(); deleteEmpresa(${empresa.account_id})" class="text-red-600 hover:text-red-900">Borrar</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

function getEstadoColor(estado) {
    const colors = {
        'Activo': 'bg-red-100 text-red-800',
        'Latente': 'bg-yellow-100 text-yellow-800',
        'Dialogo': 'bg-green-100 text-green-800',
        'NoDialogo': 'bg-gray-100 text-gray-800'
    };
    return colors[estado] || 'bg-gray-100 text-gray-800';
}

function getTierClass(tier) {
    const classes = {
        'Tier 1': 'bg-red-100 text-red-800 border-red-300',
        'Tier 2': 'bg-orange-100 text-orange-800 border-orange-300',
        'Tier 3': 'bg-yellow-100 text-yellow-800 border-yellow-300',
        'Monitoreo': 'bg-gray-100 text-gray-800 border-gray-300'
    };
    return classes[tier] || 'bg-gray-100 text-gray-800';
}

// ==================== SEMANAL VIEW ====================
function renderSemanalTable() {
    const tbody = document.getElementById('semanal-table-body');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    // Get Tier 1 companies
    const tier1 = db.empresas
        .filter(e => e.gestion?.tier === 'Tier 1')
        .sort((a, b) => (b.gestion?.score_total || 0) - (a.gestion?.score_total || 0))
        .slice(0, 10);
    
    // Update counters
    const countTier1 = document.getElementById('count-tier1');
    const countTareas = document.getElementById('count-tareas');
    if (countTier1) countTier1.textContent = tier1.length;
    if (countTareas) countTareas.textContent = tier1.length * 4; // 4 acciones por cuenta
    
    if (tier1.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No hay cuentas Tier 1. Importa datos y recalcula scores.</td></tr>';
        return;
    }
    
    tier1.forEach(empresa => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-red-50 cursor-pointer';
        row.onclick = () => openAccountModal(empresa.account_id);
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900">${empresa.razon_social_normalizada}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="text-lg font-bold text-red-600">${empresa.gestion?.score_total || 0}</span>
            </td>
            <td class="px-6 py-4 text-sm text-gray-500">${empresa.gestion?.próxima_acción || '-'}</td>
            <td class="px-6 py-4 text-sm text-gray-500">${empresa.gestion?.owner || 'Sin asignar'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm">
                <button onclick="event.stopPropagation(); generateActionsForEmpresa(${empresa.account_id})" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Generar Acciones</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

function updateNextExecutionDisplay() {
    const nextExecSpan = document.getElementById('next-execution');
    if (!nextExecSpan) return;
    
    if (db.config.autoSchedule && db.config.nextExecution) {
        nextExecSpan.textContent = new Date(db.config.nextExecution).toLocaleString('es-PE', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } else {
        nextExecSpan.textContent = 'No programada';
    }
}

function obtenerProximoLunes() {
    const hoy = new Date();
    const diaSemana = hoy.getDay(); // 0 = Domingo, 1 = Lunes, ...
    const diasHastaLunes = (1 - diaSemana + 7) % 7 || 7;
    const proximoLunes = new Date(hoy);
    proximoLunes.setDate(hoy.getDate() + diasHastaLunes);
    proximoLunes.setHours(9, 0, 0, 0); // 9:00 AM
    return proximoLunes.toISOString().split('T')[0];
}

// ==================== AUTOMATIZACIÓN ====================
function generateWeeklyTasks() {
    const tier1 = db.empresas.filter(e => e.gestion?.tier === 'Tier 1');
    
    if (tier1.length === 0) {
        alert('No hay cuentas Tier 1 para generar tareas');
        return;
    }
    
    let createdCount = 0;
    
    tier1.forEach(empresa => {
        // Crear 4 tareas
        const acciones = [
            '1. Correo institucional',
            '2. LinkedIn corporativo',
            '3. Llamada a central',
            '4. Enviar one-pager + propuesta'
        ];
        
        acciones.forEach((accion, index) => {
            const tarea = {
                task_id: Date.now() + Math.random(),
                account_id: empresa.account_id,
                nombre: `${accion} - ${empresa.razon_social_normalizada}`,
                fecha: obtenerProximoLunes(),
                estado: 'Pendiente',
                responsable: empresa.gestion?.owner || 'Sin asignar',
                timestamp: new Date().toISOString()
            };
            
            db.tareas.push(tarea);
            
            // Registrar en log
            logAccion(empresa.account_id, 'Tarea generada', tarea.nombre);
            
            createdCount++;
        });
        
        // Actualizar próxima acción
        empresa.gestion.próxima_acción = 'En progreso';
        empresa.gestion.fecha_próxima_acción = obtenerProximoLunes();
    });
    
    saveToStorage();
    alert(`✅ ${createdCount} tareas generadas para ${tier1.length} cuentas Tier 1`);
    
    // Actualizar vista semanal
    renderSemanalTable();
}

function toggleAutoSchedule() {
    if (!db.config.autoSchedule) {
        // Activar
        const proximoLunes = new Date();
        const diaSemana = proximoLunes.getDay();
        const diasHastaLunes = (1 - diaSemana + 7) % 7 || 7;
        proximoLunes.setDate(proximoLunes.getDate() + diasHastaLunes);
        proximoLunes.setHours(9, 0, 0, 0);
        
        db.config.autoSchedule = true;
        db.config.nextExecution = proximoLunes.toISOString();
        
        alert(`✅ Programación activada\nPróxima ejecución: ${proximoLunes.toLocaleString('es-PE')}\n\nNota: Esta es una simulación. En producción, usarías cron job o setInterval.`);
        
        // Simular chequeo cada minuto (solo para demo)
        setInterval(() => {
            checkScheduledExecution();
        }, 60000);
        
    } else {
        db.config.autoSchedule = false;
        db.config.nextExecution = null;
        alert('❌ Programación desactivada');
    }
    
    saveToStorage();
    updateNextExecutionDisplay();
}

function checkScheduledExecution() {
    if (!db.config.autoSchedule || !db.config.nextExecution) return;
    
    const now = new Date();
    const nextExec = new Date(db.config.nextExecution);
    
    if (now >= nextExec) {
        console.log('⏰ Ejecución programada activada');
        generateWeeklyTasks();
        
        // Proxima semana
        const proximaSemana = new Date(nextExec);
        proximaSemana.setDate(proximaSemana.getDate() + 7);
        db.config.nextExecution = proximaSemana.toISOString();
        saveToStorage();
        updateNextExecutionDisplay();
    }
}

function generateActionsForEmpresa(accountId) {
    const empresa = db.empresas.find(e => e.account_id === accountId);
    if (!empresa) return;
    
    const acciones = [
        'Correo institucional',
        'LinkedIn corporativo',
        'Llamada a central',
        'Enviar one-pager'
    ];
    
    let msg = `Acciones generadas para ${empresa.razon_social_normalizada}:\n\n`;
    
    acciones.forEach(accion => {
        const tarea = {
            task_id: Date.now() + Math.random(),
            account_id: accountId,
            nombre: `${accion} - ${empresa.razon_social_normalizada}`,
            fecha: new Date().toISOString().split('T')[0],
            estado: 'Pendiente',
            responsable: empresa.gestion?.owner || 'Sin asignar',
            timestamp: new Date().toISOString()
        };
        
        db.tareas.push(tarea);
        logAccion(accountId, 'Acción manual generada', accion);
        msg += `✓ ${accion}\n`;
    });
    
    saveToStorage();
    alert(msg);
}

// ==================== MODAL ACCOUNT ====================
function openAccountModal(accountId) {
    const empresa = db.empresas.find(e => e.account_id === accountId);
    if (!empresa) return;
    
    const modal = document.getElementById('account-modal');
    const nombre = document.getElementById('modal-account-name');
    const meta = document.getElementById('modal-account-meta');
    
    nombre.textContent = empresa.razon_social_normalizada;
    meta.textContent = `${empresa.región} | ${empresa.sector} | Score: ${empresa.gestion?.score_total || 0} | Tier: ${empresa.gestion?.tier || 'N/A'}`;
    
    // Load tabs
    loadModalResumen(accountId);
    loadModalCasos(accountId);
    loadModalSenales(accountId);
    loadModalCanales(accountId);
    loadModalLog(accountId);
    
    modal.classList.add('active');
}

function closeAccountModal() {
    const modal = document.getElementById('account-modal');
    modal.classList.remove('active');
}

function showModalTab(tabName) {
    // Hide all modal contents
    document.querySelectorAll('.modal-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Show selected
    const selected = document.getElementById(`modal-content-${tabName}`);
    if (selected) selected.classList.add('active');
    
    // Update tabs
    document.querySelectorAll('.modal-tab').forEach(tab => {
        tab.classList.remove('text-blue-600', 'border-b-2', 'border-blue-600');
        tab.classList.add('text-gray-500');
    });
    
    const activeTab = document.querySelector(`.modal-tab[data-tab="${tabName}"]`);
    if (activeTab) {
        activeTab.classList.remove('text-gray-500');
        activeTab.classList.add('text-blue-600', 'border-b-2', 'border-blue-600');
    }
}

function loadModalResumen(accountId) {
    const empresa = db.empresas.find(e => e.account_id === accountId);
    const corporativosDiv = document.getElementById('modal-corporativos');
    const scoringDiv = document.getElementById('modal-scoring');
    
    if (corporativosDiv) {
        corporativosDiv.innerHTML = `
            <p><strong>RUC:</strong> ${empresa.ruc || 'N/A'}</p>
            <p><strong>Nombre Comercial:</strong> ${empresa.nombre_comercial}</p>
            <p><strong>Web:</strong> ${empresa.web_oficial}</p>
            <p><strong>Teléfono:</strong> ${empresa.central_tel_oficial}</p>
            <p><strong>Email:</strong> ${empresa.correo_institucional}</p>
            <p><strong>País/Región:</strong> ${empresa.país}/${empresa.región}</p>
            <p><strong>Tamaño:</strong> ${empresa.tamaño_proxy}</p>
        `;
    }
    
    if (scoringDiv) {
        const score = empresa.gestion?.score_total || 0;
        const tier = empresa.gestion?.tier || 'N/A';
        const proxima = empresa.gestion?.próxima_acción || '-';
        const fecha = empresa.gestion?.fecha_próxima_acción || '-';
        
        scoringDiv.innerHTML = `
            <p><strong>Score Total:</strong> <span class="text-2xl font-bold ${score >= 75 ? 'text-red-600' : score >= 50 ? 'text-orange-600' : 'text-yellow-600'}">${score}</span></p>
            <p><strong>Tier:</strong> <span class="font-semibold">${tier}</span></p>
            <p><strong>Próxima Acción:</strong> ${proxima}</p>
            <p><strong>Fecha Próxima:</strong> ${fecha}</p>
            <p><strong>Owner:</strong> ${empresa.gestion?.owner || 'Sin asignar'}</p>
            <p><strong>Etapa Pipeline:</strong> ${empresa.gestion?.etapa_pipeline || 'Lead'}</p>
        `;
    }
}

function loadModalCasos(accountId) {
    const casos = db.casos.filter(c => c.account_id === accountId);
    const container = document.getElementById('modal-casos-list');
    
    if (!container) return;
    
    if (casos.length === 0) {
        container.innerHTML = '<p class="text-gray-500">No hay casos registrados</p>';
        return;
    }
    
    container.innerHTML = casos.map(c => `
        <div class="bg-gray-50 p-3 rounded border">
            <div class="flex justify-between items-start mb-1">
                <span class="font-semibold text-gray-900">${c.nombre_caso}</span>
                <span class="px-2 py-1 text-xs rounded ${getEstadoColor(c.estado)}">${c.estado}</span>
            </div>
            <p class="text-sm text-gray-600">${c.ubicación_dep} - ${c.ubicación_prov} - ${c.ubicación_dist}</p>
            <p class="text-xs text-gray-500 mt-1">${c.tipo_conflicto} | ${c.fecha_reporte}</p>
            <p class="text-xs text-gray-700 mt-2">${c.motivo_resumen}</p>
            <p class="text-xs text-blue-600 mt-1 truncate">${c.fuente_primaria} ${c.url_fuente ? `| ${c.url_fuente}` : ''}</p>
        </div>
    `).join('');
}

function loadModalSenales(accountId) {
    const señales = db.señales.filter(s => s.account_id === accountId);
    const container = document.getElementById('modal-senales-list');
    
    if (!container) return;
    
    if (señales.length === 0) {
        container.innerHTML = '<p class="text-gray-500">No hay señales registradas</p>';
        return;
    }
    
    container.innerHTML = señales.map(s => `
        <div class="bg-gray-50 p-3 rounded border">
            <div class="flex justify-between items-start mb-1">
                <span class="font-semibold text-gray-900">${s.tipo_señal}</span>
                <span class="px-2 py-1 text-xs rounded bg-purple-100 text-purple-800">Severidad: ${s.severidad}</span>
            </div>
            <p class="text-sm text-gray-700">${s.resumen}</p>
            <p class="text-xs text-gray-500 mt-1">${s.fecha}</p>
            ${s.url ? `<a href="${s.url}" target="_blank" class="text-xs text-blue-600 hover:underline">Ver fuente</a>` : ''}
        </div>
    `).join('');
}

function loadModalCanales(accountId) {
    const canales = db.contactos.filter(c => c.account_id === accountId);
    const container = document.getElementById('modal-canales-list');
    
    if (!container) return;
    
    if (canales.length === 0) {
        container.innerHTML = '<p class="text-gray-500">No hay canales registrados</p>';
        return;
    }
    
    container.innerHTML = canales.map(c => `
        <div class="bg-gray-50 p-3 rounded border">
            <div class="flex justify-between items-start mb-1">
                <span class="font-semibold text-gray-900">${c.tipo}</span>
                <span class="px-2 py-1 text-xs rounded ${c.verificado === 'Sí' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}">${c.verificado}</span>
            </div>
            <p class="text-sm text-gray-700">${c.detalle}</p>
            ${c.url ? `<a href="${c.url}" target="_blank" class="text-xs text-blue-600 hover:underline">Ver</a>` : ''}
            <p class="text-xs text-gray-500 mt-1">Verificado: ${c.fecha_verificación}</p>
        </div>
    `).join('');
}

function loadModalLog(accountId) {
    const logs = db.logs.filter(l => l.account_id === accountId);
    const container = document.getElementById('modal-log');
    
    if (!container) return;
    
    if (logs.length === 0) {
        container.innerHTML = '<p class="text-gray-500">No hay registros de acciones</p>';
        return;
    }
    
    container.innerHTML = logs.map(l => `
        <div class="mb-2">
            <span class="text-gray-400">[${new Date(l.timestamp).toLocaleString('es-PE')}]</span>
            <span class="font-semibold">${l.accion}:</span>
            <span class="text-gray-700">${l.detalles}</span>
        </div>
    `).join('');
}

// ==================== ACCIONES Y TAREAS ====================
function createTask() {
    const modal = document.getElementById('account-modal');
    const accountId = getAccountIdFromModal();
    
    if (!accountId) return;
    
    const nombre = document.getElementById('task-name').value;
    const fecha = document.getElementById('task-date').value;
    const notas = document.getElementById('task-notes').value;
    
    if (!nombre || !fecha) {
        alert('Nombre y fecha son obligatorios');
        return;
    }
    
    const tarea = {
        task_id: Date.now() + Math.random(),
        account_id: accountId,
        nombre: nombre,
        fecha: fecha,
        notas: notas,
        estado: 'Pendiente',
        responsable: 'Sin asignar',
        timestamp: new Date().toISOString()
    };
    
    db.tareas.push(tarea);
    logAccion(accountId, 'Tarea creada', nombre);
    saveToStorage();
    
    alert('✅ Tarea creada');
    
    // Clear inputs
    document.getElementById('task-name').value = '';
    document.getElementById('task-date').value = '';
    document.getElementById('task-notes').value = '';
    
    loadModalLog(accountId);
}

function startCadence(tipo) {
    const accountId = getAccountIdFromModal();
    if (!accountId) return;
    
    const empresa = db.empresas.find(e => e.account_id === accountId);
    if (!empresa) return;
    
    let mensaje = '';
    let accion = '';
    
    switch(tipo) {
        case 'email':
            mensaje = db.templates.email
                .replace('[Empresa]', empresa.razon_social_normalizada)
                .replace('[N°]', db.casos.filter(c => c.account_id === accountId).length)
                .replace('[tipo_conflicto]', db.casos.find(c => c.account_id === accountId)?.tipo_conflicto || 'varios')
                .replace('[ubicación]', empresa.región);
            accion = 'Correo institucional enviado';
            break;
            
        case 'linkedin':
            mensaje = db.templates.linkedin
                .replace('[Empresa]', empresa.razon_social_normalizada)
                .replace('[región]', empresa.región)
                .replace('[N°]', db.señales.filter(s => s.account_id === accountId).length);
            accion = 'LinkedIn corporativo enviado';
            break;
            
        case 'call':
            mensaje = `Llamar a: ${empresa.central_tel_oficial}\nSolicitar: Área de Gestión Social\nMensaje: "Buenos días, soy [nombre] de ORASI Lab. Tenemos un análisis sobre casos en ${empresa.región}."`;
            accion = 'Llamada a central registrada';
            break;
            
        case 'proposal':
            mensaje = db.templates.onepager
                .replace('[Razón Social]', empresa.razon_social_normalizada)
                .replace('[Fecha análisis]', new Date().toISOString().split('T')[0])
                .replace('[N°]', db.casos.filter(c => c.account_id === accountId).length);
            accion = 'One-pager + propuesta enviada';
            break;
    }
    
    // Registrar en log
    logAccion(accountId, accion, mensaje.substring(0, 100) + '...');
    
    // Mostrar mensaje
    alert(`${accion}:\n\n${mensaje}`);
    
    loadModalLog(accountId);
}

function getAccountIdFromModal() {
    // Extract account_id from modal meta text (hacky but works)
    const metaText = document.getElementById('modal-account-meta')?.textContent || '';
    const empresas = db.empresas.filter(e => metaText.includes(e.razon_social_normalizada));
    return empresas.length > 0 ? empresas[0].account_id : null;
}

function logAccion(accountId, accion, detalles) {
    db.logs.push({
        log_id: Date.now() + Math.random(),
        account_id: accountId,
        accion: accion,
        detalles: detalles,
        timestamp: new Date().toISOString()
    });
}

// ==================== EXPORT ====================
function exportData() {
    if (db.empresas.length === 0) {
        alert('No hay datos para exportar');
        return;
    }
    
    let csv = 'account_id,razon_social,region,score,tier,estado,proxima_accion,owner,casos,señales,canales\n';
    
    db.empresas.forEach(empresa => {
        const casos = db.casos.filter(c => c.account_id === empresa.account_id).length;
        const señales = db.señales.filter(s => s.account_id === empresa.account_id).length;
        const canales = db.contactos.filter(c => c.account_id === empresa.account_id).length;
        const estado = db.casos.find(c => c.account_id === empresa.account_id)?.estado || 'N/A';
        
        csv += `${empresa.account_id},"${empresa.razon_social_normalizada}",${empresa.región},${empresa.gestion?.score_total || 0},${empresa.gestion?.tier || 'N/A'},${estado},"${empresa.gestion?.próxima_acción || '-'}","${empresa.gestion?.owner || 'Sin asignar'}",${casos},${señales},${canales}\n`;
    });
    
    // Download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orasi_radar_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    
    // Log
    db.logs.push({
        log_id: Date.now(),
        account_id: null,
        accion: 'Exportación CSV',
        detalles: `Exportadas ${db.empresas.length} empresas`,
        timestamp: new Date().toISOString()
    });
    saveToStorage();
}

// ==================== TEMPLATES ====================
function loadTemplates() {
    if (!db.templates) return;
    
    const emailInput = document.getElementById('template-email');
    const linkedinInput = document.getElementById('template-linkedin');
    const onepagerInput = document.getElementById('template-onepager');
    
    if (emailInput) emailInput.value = db.templates.email;
    if (linkedinInput) linkedinInput.value = db.templates.linkedin;
    if (onepagerInput) onepagerInput.value = db.templates.onepager;
}

function saveTemplates() {
    const emailInput = document.getElementById('template-email');
    const linkedinInput = document.getElementById('template-linkedin');
    const onepagerInput = document.getElementById('template-onepager');
    
    if (emailInput && linkedinInput && onepagerInput) {
        db.templates.email = emailInput.value;
        db.templates.linkedin = linkedinInput.value;
        db.templates.onepager = onepagerInput.value;
        
        saveToStorage();
        alert('✅ Plantillas guardadas');
    }
}

// ==================== SAMPLE DATA ====================
function processSampleData() {
    const sampleCSV = `Empresa,Caso,Departamento,Provincia,Distrito,Estado,Tipo,Fuente primaria,Notas,URL
Minera Antamina,Conflicto comunal,Ancash,Santa,Chimbote,Activo,Ambiental,OEFA,Requerimiento de medidas ambientales,https://oefa.gob.pe/resoluciones/antamina-2024
Minera Southern Copper,Paro de personal,Moquegua,Tacna,Ilo,Latente,Laboral,Defensoría,Reclamos salariales y condiciones,https://defensoria.gob.pe/alertas/southern-2024
Minera Yanacocha,Conflictividad social,La Libertad,Trujillo,Moche,Dialogo,Social,Defensoría,Mesa de diálogo activa,https://defensoria.gob.pe/mesas/yanacocha-2024
Minera Cerro Verde,Bloqueo de vías,Arequipa,Arequipa,Cerro Colorado,Activo,Ambiental,Prensa regional,Bloqueo por contaminación,https://noticiasarequipa.pe/bloqueo-cerro-verde
Minera Las Bambas,Conflictividad multiactor,Cusco,Cotabambas,Challhuahuacho,Activo,Social,OEFA,Múltiples comunidades,https://oefa.gob.pe/lasbambas-2024
Minera Shahuindo,Expansión de proyecto,La Libertad,Trujillo,Salaverry,Latente,Ambiental,Ministerio del Ambiente,Estudio de impacto ambiental,https://minam.gob.pe/shahuindo-2024
Minera Quellaveco,Agua y medio ambiente,Moquegua,Tacna,Ilo,Dialogo,Ambiental,Defensoría,Gestión de recursos hídricos,https://defensoria.gob.pe/quellaveco-2024
Minera Toromocho,Desplazamiento de población,Central,Huancayo,El Tambo,Latente,Social,Defensoría,Reasentamiento de comunidades,https://defensoria.gob.pe/toromocho-2024
Minera Raura,Contaminación de ríos,Lima,Huarochirí,San Mateo,Activo,Ambiental,OEFA,Vertimientos mineros,https://oefa.gob.pe/raura-2024
Minera Pierina,Empleo y comunidad,Ancash,Santa,María,Dialogo,Social,Defensoría,Acuerdos de empleo local,https://defensoria.gob.pe/pierina-2024`;
    
    processCSV(sampleCSV);
    
    // Show success message
    const validationDiv = document.getElementById('validation-results');
    if (validationDiv) {
        validationDiv.classList.remove('hidden');
        const messagesDiv = document.getElementById('validation-messages');
        if (messagesDiv) {
            messagesDiv.innerHTML = '<p class="text-green-600 font-semibold">✅ Datos de ejemplo cargados correctamente</p><p class="text-gray-600 text-sm">10 empresas importadas. Puedes verlas en el Radar.</p>';
        }
    }
}

// ==================== CLEAR DATA ====================
function clearAllData() {
    if (!confirm('⚠️ ¿Seguro que quieres borrar todos los datos? Esta acción no se puede deshacer.')) return;
    
    db = {
        empresas: [],
        casos: [],
        señales: [],
        contactos: [],
        tareas: [],
        logs: [],
        templates: db.templates,
        config: { autoSchedule: false, lastExecution: null, nextExecution: null }
    };
    
    saveToStorage();
    renderRadarTable();
    renderSemanalTable();
    
    alert('✅ Todos los datos han sido borrados');
}

function deleteEmpresa(accountId) {
    if (!confirm('¿Seguro que quieres borrar esta empresa y todos sus datos relacionados?')) return;
    
    db.empresas = db.empresas.filter(e => e.account_id !== accountId);
    db.casos = db.casos.filter(c => c.account_id !== accountId);
    db.señales = db.señales.filter(s => s.account_id !== accountId);
    db.contactos = db.contactos.filter(c => c.account_id !== accountId);
    db.tareas = db.tareas.filter(t => t.account_id !== accountId);
    db.logs = db.logs.filter(l => l.account_id !== accountId);
    
    saveToStorage();
    renderRadarTable();
    renderSemanalTable();
    
    alert('✅ Empresa borrada');
}

// ==================== VALIDATION UI ====================
function showValidationResults(success, errors, messages) {
    const validationDiv = document.getElementById('validation-results');
    const messagesDiv = document.getElementById('validation-messages');
    
    if (!validationDiv || !messagesDiv) return;
    
    validationDiv.classList.remove('hidden');
    
    let html = `<p class="font-semibold ${errors > 0 ? 'text-orange-600' : 'text-green-600'}">`;
    html += `✅ ${success} filas procesadas ${errors > 0 ? `| ⚠️ ${errors} errores` : ''}`;
    html += '</p>';
    
    if (messages.length > 0) {
        html += '<div class="mt-2 space-y-1 text-red-600">';
        messages.forEach(msg => {
            html += `<p>${msg}</p>`;
        });
        html += '</div>';
    }
    
    html += '<p class="text-xs text-gray-500 mt-2">Recuerda: Todas las filas deben tener Fuente primaria + Fecha + URL para trazabilidad completa.</p>';
    
    messagesDiv.innerHTML = html;
}