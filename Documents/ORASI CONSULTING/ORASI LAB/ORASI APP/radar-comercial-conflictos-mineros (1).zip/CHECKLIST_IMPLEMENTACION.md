# ✅ CHECKLIST DE IMPLEMENTACIÓN - ORASI Lab

## FASE 1: SETUP INICIAL (Día 1)

### 1.1 Archivos
- [x] `index.html` - Interfaz principal
- [x] `app.js` - Lógica de negocio
- [x] `plantilla_base_conflictos_mineros_starter.csv` - Plantilla ejemplo
- [x] `README.md` - Documentación completa

### 1.2 Prueba de Concepto
- [ ] Abrir `index.html` en navegador
- [ ] Verificar que carga sin errores en consola (F12)
- [ ] Click "Cargar Datos de Ejemplo"
- [ ] Validar que aparecen 10 empresas en Radar
- [ ] Verificar cálculo de scores (debería mostrar valores entre 30-100)

---

## FASE 2: VALIDACIÓN DE DATOS (Día 2)

### 2.1 Estructura de Datos
```bash
# Verificar en consola del navegador:
db.empresas.length    # Debe ser > 0
db.casos.length       # Debe ser > 0
db.señales.length     # Debe ser > 0
```

### 2.2 Scoring Manual
Calcular manualmente para 3 empresas y comparar:

**Empresa 1: Minera Antamina**
- [ ] Estado: Activo → 15 pts
- [ ] Señal reciente (15 días) → 15 pts
- [ ] Severidad: 5 → 20 pts
- [ ] Bloqueo: Sí → 5 pts
- [ ] Comunidades: 1 → 0 pts
- [ ] Autoridades: 1 → 0 pts
- [ ] Mesa: No → 0 pts
- [ ] Tamaño: Grande → 15 pts
- [ ] Canales verificados: 1 → 5 pts
- [ ] **Score calculado**: 75
- [ ] **Score mostrado**: _____ (verificar)

**Empresa 2: Minera Southern Copper**
- [ ] Estado: Latente → 10 pts
- [ ] Señal reciente (60 días) → 8 pts
- [ ] Severidad: 3 → 12 pts
- [ ] Bloqueo: No → 0 pts
- [ ] Comunidades: 1 → 0 pts
- [ ] Autoridades: 1 → 0 pts
- [ ] Mesa: No → 0 pts
- [ ] Tamaño: Grande → 15 pts
- [ ] Canales verificados: 1 → 5 pts
- [ ] **Score calculado**: 50
- [ ] **Score mostrado**: _____ (verificar)

**Empresa 3: Minera Las Bambas**
- [ ] Estado: Activo → 15 pts
- [ ] Señal reciente (30 días) → 15 pts
- [ ] Severidad: 5 → 20 pts
- [ ] Bloqueo: No → 0 pts
- [ ] Comunidades: 3 → 8 pts
- [ ] Autoridades: 2 → 7 pts
- [ ] Mesa: No → 0 pts
- [ ] Tamaño: Grande → 15 pts
- [ ] Canales verificados: 1 → 5 pts
- [ ] **Score calculado**: 85
- [ ] **Score mostrado**: _____ (verificar)

### 2.3 Asignación de Tiers
- [ ] Score ≥75 → Tier 1
- [ ] Score 50-74 → Tier 2
- [ ] Score 25-49 → Tier 3
- [ ] Score <25 → Monitoreo

---

## FASE 3: PRUEBAS DE FUNCIONALIDAD (Día 3)

### 3.1 Importación de Datos
- [ ] Subir CSV con formato correcto → ✅ Éxito
- [ ] Subir CSV sin columna obligatoria → ❌ Error correcto
- [ ] Subir CSV vacío → ❌ Error correcto
- [ ] Verificar deduplicación (mismo RUC) → ✅ No duplica

### 3.2 Filtros del Radar
- [ ] Filtrar por región → Resultados correctos
- [ ] Filtrar por estado → Resultados correctos
- [ ] Filtrar por tipo → Resultados correctos
- [ ] Filtrar por score mínimo → Resultados correctos
- [ ] Filtrar por tier → Resultados correctos
- [ ] Combinar múltiples filtros → Resultados correctos
- [ ] Limpiar filtros → Muestra todos

### 3.3 Vista de Cuenta (Modal)
- [ ] Click en empresa → Modal abre
- [ ] Pestaña "Resumen" → Muestra datos corporativos y scoring
- [ ] Pestaña "Casos" → Lista todos los casos vinculados
- [ ] Pestaña "Señales" → Lista señales con severidad
- [ ] Pestaña "Canales" → Muestra canales verificados
- [ ] Pestaña "Acciones" → Puede crear tareas y cadencias

### 3.4 Vista Semanal
- [ ] Verificar Top 10 Tier 1
- [ ] Contador de cuentas Tier 1
- [ ] Contador de tareas a generar
- [ ] Click "Generar Tareas Ahora" → Crea 4 tareas por cuenta

---

## FASE 4: AUTOMATIZACIÓN (Día 4)

### 4.1 Programación
- [ ] Click "Activar Programación"
- [ ] Verificar que muestra próxima ejecución (lunes 9:00 AM)
- [ ] Simular paso del tiempo (cambiar fecha manual en código)
- [ ] Verificar que genera tareas automáticamente

### 4.2 Tareas Generadas
- [ ] 1. Correo institucional (plantilla)
- [ ] 2. LinkedIn corporativo (plantilla)
- [ ] 3. Llamada a central (tarea)
- [ ] 4. One-pager + propuesta (plantilla)

### 4.3 Logs de Auditoría
- [ ] Registrar cada acción generada
- [ ] Verificar timestamp en cada log
- [ ] Confirmar que se asocian a cuenta correcta
- [ ] Exportar log completo

---

## FASE 5: CUMPLIMIENTO Y SEGURIDAD (Día 5)

### 5.1 Privacidad
- [ ] Verificar que NO se guardan números de celular personales
- [ ] Verificar que NO se guardan DNI
- [ ] Verificar que NO se guardan nombres de comuneros
- [ ] Solo datos corporativos verificados

### 5.2 Trazabilidad
- [ ] Toda empresa tiene fuente primaria
- [ ] Toda empresa tiene fecha de captura
- [ ] Toda empresa tiene URL/Referencia (cuando aplica)
- [ ] Exportar CSV con trazabilidad completa

### 5.3 Ética Comercial
- [ ] Plantillas no son spam
- [ ] Mensaje consultivo, no oportunista
- [ ] Ofrece valor antes de venta
- [ ] Respeta "No contactar"

---

## FASE 6: PRUEBAS DE INTEGRACIÓN (Día 6)

### 6.1 Flujo Completo
```
Importar CSV → Filtros → Ver Cuenta → Crear Tarea → Generar Cadencia → Ver Log → Exportar
```

### 6.2 Casos Especiales
- [ ] Empresa con múltiples casos (1:N)
- [ ] Empresa sin señales
- [ ] Empresa sin canales verificados
- [ ] Empresa con score 0
- [ ] Empresa con score 100

### 6.3 Límites
- [ ] Importar 100 registros → Performance < 2s
- [ ] Exportar 100 registros → CSV completo
- [ ] Filtros combinados → Resultados correctos

---

## FASE 7: DOCUMENTACIÓN Y CAPACITACIÓN (Día 7)

### 7.1 Documentación
- [x] README.md completo
- [x] Diccionario de datos
- [x] Fórmulas de scoring
- [x] Plantillas de mensajes
- [x] Reglas de cumplimiento
- [x] Checklist de go-live

### 7.2 Capacitación
- [ ] Manual de usuario (paso a paso)
- [ ] Video tutorial (opcional)
- [ ] Sesión de preguntas y respuestas
- [ ] Práctica supervisada

---

## FASE 8: GO-LIVE (Día 8)

### 8.1 Pre-Producción
- [ ] Dataset real cargado (mínimo 20 empresas)
- [ ] Scores validados manualmente
- [ ] Tiers confirmados
- [ ] Plantillas aprobadas por compliance

### 8.2 Producción
- [ ] Backup inicial exportado
- [ ] Responsable definido
- [ ] Proceso de actualización mensual documentado
- [ ] SLA establecido (actualización cada 30 días)

### 8.3 Monitoreo
- [ ] Métricas de éxito definidas
- [ ] Dashboard de KPIs
- [ ] Reporte semanal de Tier 1
- [ ] Log de auditoría mensual

---

## 🎯 MÉTRICAS DE VALIDACIÓN

| Prueba | Expected | Actual | Status |
|--------|----------|--------|--------|
| Importar 10 registros | ✅ Success | | |
| Calcular score manual | ±5% error | | |
| Filtros funcionan | 100% | | |
| Modal abre | <1s | | |
| Tareas generadas | 4×Tier1 | | |
| Exportar CSV | Completo | | |
| Logs registrados | 100% | | |

---

## 📝 NOTAS DE IMPLEMENTACIÓN

### **Supuestos Declarados**
1. **Almacenamiento**: LocalStorage (navegador) - no multi-usuario
2. **Automatización**: Requiere navegador abierto
3. **Escalabilidad**: Hasta 500 empresas sin problemas
4. **Multi-tenant**: No implementado (requiere backend)

### **Alternativas para Escalar**
- **Backend**: Node.js + PostgreSQL + Bull Queue
- **Cloud**: AWS Lambda + DynamoDB + EventBridge
- **Multi-tenant**: Auth0 + DB por usuario

### **Riesgos Identificados**
1. **Data loss**: localStorage se borra si limpian caché → **Mitigación**: Exportar CSV semanal
2. **Single user**: No sincronización → **Mitigación**: Backend en futuro
3. **No offline**: Requiere navegador → **Mitigación**: PWA en futuro

---

## ✅ CERTIFICACIÓN FINAL

**Fecha de Go-Live**: ___________

**Responsable**: ___________

**Checklist completo**: ✅

**Aprobado por**: ___________

**Firma**: ___________

---

**NOTA**: Este checklist debe completarse antes de usar el sistema con datos reales de clientes.