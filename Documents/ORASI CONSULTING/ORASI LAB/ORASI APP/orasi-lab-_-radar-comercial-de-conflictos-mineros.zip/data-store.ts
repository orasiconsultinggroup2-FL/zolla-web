
import { 
  Account, Case, Signal, Channel, InteractionLog, 
  ConflictStatus, SignalSeverity, Tier, PipelineStage, AppState 
} from './types';
import { SCORING_WEIGHTS } from './constants';

const initialAccounts: Account[] = [
  {
    id: 'acc_01',
    razonSocial: 'Compañía Minera Antamina S.A.',
    nombreComercial: 'Antamina',
    webOficial: 'https://www.antamina.com',
    centralTelOficial: '+51 1 217 3000',
    correoInstitucional: 'mesadepartes@antamina.com',
    sector: 'Minería',
    pais: 'Perú',
    region: 'Ancash',
    proyectosUEA: ['Antamina'],
    tamanoProxy: 'Grande',
    ultimaActualizacion: new Date().toISOString(),
    owner: 'Carlos Revilla',
    etapaPipeline: PipelineStage.DISCOVERY,
    scoreTotal: 85,
    tier: Tier.TIER1,
    proximaAccion: 'Enviar Propuesta Inicial',
    fechaProximaAccion: '2024-05-20'
  },
  {
    id: 'acc_02',
    razonSocial: 'Southern Peru Copper Corporation',
    nombreComercial: 'Southern Copper',
    webOficial: 'https://www.southernperu.com',
    centralTelOficial: '+51 1 512 0440',
    correoInstitucional: 'contacto@southernperu.com.pe',
    sector: 'Minería',
    pais: 'Perú',
    region: 'Moquegua',
    proyectosUEA: ['Cuajone', 'Toquepala', 'Ilo'],
    tamanoProxy: 'Grande',
    ultimaActualizacion: new Date().toISOString(),
    owner: 'Lucía Mendoza',
    etapaPipeline: PipelineStage.PROSPECTING,
    scoreTotal: 72,
    tier: Tier.TIER1,
    proximaAccion: 'Llamada Central',
    fechaProximaAccion: '2024-05-21'
  }
];

const initialCases: Case[] = [
  {
    id: 'case_01',
    accountId: 'acc_01',
    nombreCaso: 'Mesa de diálogo San Marcos',
    ubicacion: { dep: 'Ancash', prov: 'Huari', dist: 'San Marcos' },
    tipoConflicto: 'Socioambiental',
    estado: ConflictStatus.DIALOGO,
    motivoResumen: 'Demandas por inversión en proyectos de saneamiento y compromisos previos.',
    fechaReporte: '2024-04-15',
    fuentePrimaria: 'Defensoría del Pueblo (Reporte 241)',
    urlFuente: 'https://www.defensoria.gob.pe/conflictos-sociales'
  },
  {
    id: 'case_02',
    accountId: 'acc_02',
    nombreCaso: 'Conflicto Tía María (Latente)',
    ubicacion: { dep: 'Arequipa', prov: 'Islay', dist: 'Cocachacra' },
    tipoConflicto: 'Socioambiental',
    estado: ConflictStatus.LATENTE,
    motivoResumen: 'Oposición de sectores agrícolas a la explotación minera por temor a contaminación.',
    fechaReporte: '2024-03-10',
    fuentePrimaria: 'Noticias Mineras del Sur',
    urlFuente: 'https://noticiasmineras.com/tia-maria'
  }
];

const initialSignals: Signal[] = [
  {
    id: 'sig_01',
    accountId: 'acc_01',
    tipo: 'Prensa',
    severidad: SignalSeverity.HIGH,
    fecha: '2024-05-12',
    resumen: 'Anuncio de paro de 48 horas en vía de acceso.',
    url: 'https://elcomercio.pe/regiones/ancash/paro-antamina'
  }
];

const initialChannels: Channel[] = [
  {
    id: 'chan_01',
    accountId: 'acc_01',
    tipo: 'Mesa de Partes',
    detalle: 'Virtual',
    url: 'https://mesadepartes.antamina.com',
    verificado: true,
    fechaVerificacion: '2024-01-01'
  }
];

export const calculateScore = (
  account: Account, 
  cases: Case[], 
  signals: Signal[], 
  channels: Channel[]
): { score: number, tier: Tier } => {
  let score = 0;
  
  // 1. Urgencia (30%) - Basado en estados de conflicto y señales recientes
  const hasActive = cases.some(c => c.estado === ConflictStatus.ACTIVO || c.estado === ConflictStatus.NO_DIALOGO);
  const urgencyPoints = hasActive ? 100 : (cases.some(c => c.estado === ConflictStatus.DIALOGO) ? 60 : 30);
  score += urgencyPoints * SCORING_WEIGHTS.urgency;

  // 2. Exposición (20%) - Basado en severidad de señales
  const maxSeverity = signals.length > 0 ? Math.max(...signals.map(s => s.severidad)) : 1;
  const exposurePoints = (maxSeverity / 5) * 100;
  score += exposurePoints * SCORING_WEIGHTS.exposure;

  // 3. Complejidad multi-actor (20%) - Múltiples casos = más complejidad
  const complexityPoints = Math.min(cases.length * 25, 100);
  score += complexityPoints * SCORING_WEIGHTS.complexity;

  // 4. Capacidad de compra proxy (15%)
  const buyMap = { Grande: 100, Mediana: 60, Pequeña: 30 };
  score += buyMap[account.tamanoProxy] * SCORING_WEIGHTS.buyCapacity;

  // 5. Accesibilidad comercial (15%) - Canales verificados
  const verifiedCount = channels.filter(c => c.verificado).length;
  const accessPoints = Math.min(verifiedCount * 33.3, 100);
  score += accessPoints * SCORING_WEIGHTS.accessibility;

  let tier = Tier.TIER3;
  if (score >= 75) tier = Tier.TIER1;
  else if (score >= 50) tier = Tier.TIER2;

  return { score: Math.round(score), tier };
};

export const initialState: AppState = {
  accounts: initialAccounts,
  cases: initialCases,
  signals: initialSignals,
  channels: initialChannels,
  logs: []
};
