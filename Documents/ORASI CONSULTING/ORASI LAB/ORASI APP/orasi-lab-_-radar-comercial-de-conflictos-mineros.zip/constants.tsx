
import React from 'react';
import { Globe } from 'lucide-react';

export const APP_NAME = "ORASI Lab";
export const APP_FULL_NAME = "Radar Comercial de Conflictos Mineros";

export const LOGO = (
  <div className="flex items-center gap-2">
    <div className="bg-indigo-600 p-1.5 rounded-full">
      <Globe className="w-5 h-5 text-white" />
    </div>
    <span className="font-bold text-xl tracking-tight text-slate-800">ORASI Lab</span>
  </div>
);

export const SCORING_WEIGHTS = {
  urgency: 0.30,
  exposure: 0.20,
  complexity: 0.20,
  buyCapacity: 0.15,
  accessibility: 0.15
};

export const EMAIL_TEMPLATE = `
Asunto: Propuesta de Colaboración - Gestión de Relaciones Comunitarias y Mitigación de Conflictos

Estimados [Nombre de la Empresa / Mesa de Partes],

Me dirijo a ustedes en representación de ORASI Consulting para presentar nuestro enfoque metodológico en la gestión proactiva de entornos sociales complejos, específicamente en relación con [Nombre del Caso/Proyecto].

Hemos analizado los reportes públicos de [Fuente Primaria] y comprendemos los desafíos actuales en la región de [Departamento]. Nuestro objetivo es ofrecer herramientas de análisis de datos y estrategias de RevOps que permitan estabilizar las operaciones y fortalecer la licencia social de manera ética y transparente.

Adjuntamos un resumen ejecutivo de nuestras intervenciones recientes. Quedamos a su disposición para agendar una breve reunión de 20 minutos por los canales institucionales que ustedes indiquen.

Atentamente,
[Owner]
ORASI Consulting | ORASI Lab
`;

export const LINKEDIN_TEMPLATE = `
Estimados [Nombre de la Empresa], hemos seguido de cerca el desarrollo de [Nombre del Proyecto/Caso] a través de fuentes oficiales. En ORASI Lab, trabajamos con líderes del sector minero para transformar datos en estrategias de mitigación de conflictos sociales. Nos gustaría explorar cómo nuestro Radar Comercial puede aportar valor a su equipo de Relaciones Institucionales. Saludos cordiales.
`;
