
import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart3, 
  Users, 
  LayoutDashboard, 
  Settings, 
  Radar, 
  FileText, 
  Bell, 
  Plus, 
  ChevronRight,
  TrendingUp,
  AlertCircle,
  Mail,
  Linkedin,
  Phone,
  CheckCircle2,
  Clock,
  ArrowRight,
  // Fix: Added missing Globe icon import
  Globe
} from 'lucide-react';
import { 
  AppState, Account, Tier, PipelineStage, 
  ConflictStatus, SignalSeverity, Case, Signal, Channel
} from './types';
import { initialState, calculateScore } from './data-store';
import { LOGO, EMAIL_TEMPLATE, LINKEDIN_TEMPLATE } from './constants';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

// --- Sub-components ---

const SidebarItem: React.FC<{ 
  icon: React.ReactNode; 
  label: string; 
  active?: boolean; 
  onClick: () => void 
}> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
      active 
        ? 'bg-indigo-50 text-indigo-700 font-semibold' 
        : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
    }`}
  >
    {icon}
    <span className="text-sm">{label}</span>
  </button>
);

const Badge: React.FC<{ children: React.ReactNode; variant?: 'indigo' | 'slate' | 'red' | 'green' | 'amber' }> = ({ children, variant = 'slate' }) => {
  const styles = {
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-100',
    slate: 'bg-slate-100 text-slate-700 border-slate-200',
    red: 'bg-red-50 text-red-700 border-red-100',
    amber: 'bg-amber-50 text-amber-700 border-amber-100',
    green: 'bg-emerald-50 text-emerald-700 border-emerald-100',
  };
  return (
    <span className={`px-2 py-0.5 text-xs font-medium border rounded-full ${styles[variant]}`}>
      {children}
    </span>
  );
};

// --- View: Dashboard ---
const DashboardView: React.FC<{ state: AppState; onAccountSelect: (acc: Account) => void }> = ({ state, onAccountSelect }) => {
  const topTier = useMemo(() => state.accounts.filter(a => a.tier === Tier.TIER1).sort((a,b) => b.scoreTotal - a.scoreTotal), [state.accounts]);
  
  const chartData = useMemo(() => {
    const counts = { [Tier.TIER1]: 0, [Tier.TIER2]: 0, [Tier.TIER3]: 0 };
    state.accounts.forEach(a => counts[a.tier]++);
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [state.accounts]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Resumen Ejecutivo</h1>
        <p className="text-slate-500">Estado general del Radar de Conflictos</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Cuentas Tier 1</span>
            <TrendingUp className="text-indigo-600 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-slate-900">{topTier.length}</p>
          <p className="text-xs text-slate-400 mt-2">Cuentas con urgencia inmediata</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Conflictos Activos</span>
            <AlertCircle className="text-red-500 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-slate-900">
            {state.cases.filter(c => c.estado === ConflictStatus.ACTIVO).length}
          </p>
          <p className="text-xs text-slate-400 mt-2">Monitoreo 24/7 activado</p>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Pipeline Proyectado</span>
            <CheckCircle2 className="text-emerald-500 w-5 h-5" />
          </div>
          <p className="text-3xl font-bold text-slate-900">$2.4M</p>
          <p className="text-xs text-slate-400 mt-2">Basado en scoring Tier 1/2</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-80">
          <h3 className="font-semibold text-slate-800 mb-6">Distribución de Tiers</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip cursor={{fill: '#f8fafc'}} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={40}>
                {chartData.map((entry, index) => (
                  <Cell key={index} fill={index === 0 ? '#4f46e5' : index === 1 ? '#6366f1' : '#94a3b8'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <h3 className="font-semibold text-slate-800 mb-4">Top 10 Tier 1 Semanal</h3>
          <div className="space-y-4">
            {topTier.slice(0, 5).map(acc => (
              <div 
                key={acc.id}
                onClick={() => onAccountSelect(acc)}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 cursor-pointer border border-transparent hover:border-slate-100 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-50 flex items-center justify-center font-bold text-indigo-700">
                    {acc.nombreComercial.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">{acc.nombreComercial}</h4>
                    <p className="text-xs text-slate-500">{acc.region} • Score {acc.scoreTotal}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- View: Account Detail ---
const AccountDetailView: React.FC<{ 
  account: Account; 
  state: AppState; 
  onBack: () => void 
}> = ({ account, state, onBack }) => {
  const cases = useMemo(() => state.cases.filter(c => c.accountId === account.id), [state.cases, account.id]);
  const signals = useMemo(() => state.signals.filter(s => s.accountId === account.id), [state.signals, account.id]);
  const channels = useMemo(() => state.channels.filter(c => c.accountId === account.id), [state.channels, account.id]);

  const [activeTab, setActiveTab] = useState<'info' | 'casos' | 'canales' | 'accion'>('info');

  return (
    <div className="space-y-6 animate-in slide-in-from-right-8 duration-300">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-sm text-slate-500 hover:text-indigo-600 transition-colors"
      >
        <ArrowRight className="w-4 h-4 rotate-180" />
        Volver al listado
      </button>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-2xl font-bold shadow-lg shadow-indigo-100">
                {account.nombreComercial.charAt(0)}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{account.razonSocial}</h1>
                <div className="flex gap-2 mt-1">
                  <Badge variant="indigo">{account.tier}</Badge>
                  <Badge variant="amber">Score: {account.scoreTotal}</Badge>
                  <Badge variant="slate">{account.region}</Badge>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-md shadow-indigo-100">
                Iniciar Cadencia
              </button>
            </div>
          </div>
        </div>

        <div className="flex border-b border-slate-100">
          {(['info', 'casos', 'canales', 'accion'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors capitalize ${
                activeTab === tab 
                  ? 'border-indigo-600 text-indigo-600' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab === 'info' ? 'Información General' : tab === 'casos' ? `Casos (${cases.length})` : tab === 'canales' ? 'Canales' : 'Plan de Acción'}
            </button>
          ))}
        </div>

        <div className="p-6">
          {activeTab === 'info' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Datos de Empresa</h3>
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-slate-50">
                    <span className="text-slate-500">RUC</span>
                    <span className="font-medium">{account.ruc || 'No Registrado'}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-50">
                    <span className="text-slate-500">Web Oficial</span>
                    <a href={account.webOficial} target="_blank" className="text-indigo-600 hover:underline">{account.webOficial}</a>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-50">
                    <span className="text-slate-500">Central Telefónica</span>
                    <span className="font-medium">{account.centralTelOficial}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-slate-50">
                    <span className="text-slate-500">Proyectos / UEA</span>
                    <div className="flex gap-1 flex-wrap justify-end">
                      {account.proyectosUEA.map(p => <Badge key={p}>{p}</Badge>)}
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider">Señales Recientes</h3>
                <div className="space-y-3">
                  {signals.length > 0 ? signals.map(sig => (
                    <div key={sig.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <div className="flex justify-between mb-1">
                        <span className="text-xs font-bold text-slate-400 uppercase">{sig.tipo}</span>
                        <span className="text-xs text-slate-400">{sig.fecha}</span>
                      </div>
                      <p className="text-sm text-slate-800 mb-2">{sig.resumen}</p>
                      <a href={sig.url} target="_blank" className="text-xs text-indigo-600 font-medium hover:underline">Ver fuente externa</a>
                    </div>
                  )) : (
                    <p className="text-sm text-slate-500 italic">No se han registrado señales de alerta recientes.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'casos' && (
            <div className="space-y-6">
              {cases.map(c => (
                <div key={c.id} className="border border-slate-200 rounded-xl p-5 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-lg font-bold text-slate-900">{c.nombreCaso}</h4>
                      <p className="text-sm text-slate-500">{c.ubicacion.dep}, {c.ubicacion.prov}, {c.ubicacion.dist}</p>
                    </div>
                    <Badge variant={c.estado === ConflictStatus.ACTIVO ? 'red' : 'amber'}>{c.estado}</Badge>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-700"><span className="font-semibold">Resumen:</span> {c.motivoResumen}</p>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Reportado: {c.fechaReporte}</span>
                    <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> Fuente: {c.fuentePrimaria}</span>
                    <a href={c.urlFuente} target="_blank" className="text-indigo-600 font-medium hover:underline ml-auto">Ver Auditoría</a>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'canales' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {channels.map(chan => (
                <div key={chan.id} className="border border-slate-200 rounded-xl p-4 flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    {chan.tipo === 'Mesa de Partes' && <FileText className="w-5 h-5 text-indigo-600" />}
                    {chan.tipo === 'LinkedIn Corporativo' && <Linkedin className="w-5 h-5 text-blue-700" />}
                    {chan.tipo === 'Central Telefónica' && <Phone className="w-5 h-5 text-slate-600" />}
                    <span className="font-semibold text-slate-800">{chan.tipo}</span>
                  </div>
                  <p className="text-xs text-slate-500">{chan.detalle}</p>
                  <div className="mt-auto pt-3 border-t border-slate-50 flex items-center justify-between">
                    {chan.verificado ? (
                      <span className="text-[10px] text-emerald-600 font-bold uppercase flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Verificado
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Pendiente</span>
                    )}
                    <a href={chan.url} target="_blank" className="text-xs text-indigo-600 font-medium">Ir al canal</a>
                  </div>
                </div>
              ))}
              <div className="border border-dashed border-slate-300 rounded-xl p-4 flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-indigo-300 hover:text-indigo-400 cursor-pointer transition-colors">
                <Plus className="w-6 h-6" />
                <span className="text-xs font-medium">Agregar Canal Verificado</span>
              </div>
            </div>
          )}

          {activeTab === 'accion' && (
            <div className="space-y-6">
              <div className="flex items-start gap-4 p-4 bg-indigo-50/50 rounded-xl border border-indigo-100">
                <div className="p-2 bg-indigo-600 rounded-lg text-white">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-indigo-900">Cadencia Recomendada: Tier 1</h4>
                  <p className="text-sm text-indigo-700">Esta cuenta requiere intervención inmediata. Siga los pasos de contacto institucional.</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="relative pl-8 space-y-8 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  <div className="relative">
                    <div className="absolute -left-8 top-1 w-6 h-6 rounded-full bg-white border-2 border-indigo-600 flex items-center justify-center text-[10px] font-bold text-indigo-600 z-10">1</div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                      <div className="flex justify-between mb-4">
                        <h5 className="font-bold text-slate-800 flex items-center gap-2"><Mail className="w-4 h-4" /> Correo Institucional</h5>
                        <button className="text-xs text-indigo-600 font-semibold hover:underline" onClick={() => {
                          navigator.clipboard.writeText(EMAIL_TEMPLATE);
                          alert('Plantilla copiada al portapapeles');
                        }}>Copiar Plantilla</button>
                      </div>
                      <pre className="text-xs text-slate-600 whitespace-pre-wrap bg-slate-50 p-3 rounded-lg border border-slate-100 italic">
                        {EMAIL_TEMPLATE.slice(0, 150)}...
                      </pre>
                    </div>
                  </div>

                  <div className="relative opacity-60">
                    <div className="absolute -left-8 top-1 w-6 h-6 rounded-full bg-white border-2 border-slate-300 flex items-center justify-center text-[10px] font-bold text-slate-400 z-10">2</div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                      <h5 className="font-bold text-slate-800 flex items-center gap-2"><Linkedin className="w-4 h-4" /> LinkedIn Corporativo</h5>
                      <p className="text-sm text-slate-500 mt-2">Programado para: T+2 días tras correo inicial.</p>
                    </div>
                  </div>

                  <div className="relative opacity-60">
                    <div className="absolute -left-8 top-1 w-6 h-6 rounded-full bg-white border-2 border-slate-300 flex items-center justify-center text-[10px] font-bold text-slate-400 z-10">3</div>
                    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                      <h5 className="font-bold text-slate-800 flex items-center gap-2"><Phone className="w-4 h-4" /> Llamada a Central</h5>
                      <p className="text-sm text-slate-500 mt-2">Programado para: T+4 días tras seguimiento LinkedIn.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- View: Import/Data Management ---
const DataManagementView: React.FC = () => {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Gestión de Datos</h1>
        <p className="text-slate-500">Importación y normalización mensual de fuentes primarias</p>
      </header>

      <div className="bg-white p-12 rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center space-y-4">
        <div className="w-16 h-16 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600">
          <Plus className="w-8 h-8" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-slate-900">Subir base_conflictos_mineros_starter.xlsx</h3>
          <p className="text-slate-500 max-w-sm mx-auto">Suelte el archivo aquí o haga clic para seleccionar desde su computadora. Soporta Excel y CSV.</p>
        </div>
        <button className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-semibold shadow-md shadow-indigo-100 hover:bg-indigo-700 transition-colors">
          Seleccionar Archivo
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" /> Reglas de Normalización
          </h4>
          <ul className="text-sm text-slate-600 space-y-2 list-disc pl-5">
            <li>Deduplicación por RUC y Razón Social Normalizada.</li>
            <li>Validación obligatoria de Fuente Primaria + URL.</li>
            <li>Enriquecimiento geográfico automático (Dep/Prov/Dist).</li>
            <li>Recálculo de Scoring tras cada importación.</li>
          </ul>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-500" /> Tareas Programadas
          </h4>
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium text-slate-700">Generación de Tiers Semanal</span>
            </div>
            <span className="text-xs font-bold text-indigo-600 uppercase">Lunes 09:00 PET</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main Application Component ---
const App: React.FC = () => {
  const [view, setView] = useState<'dashboard' | 'accounts' | 'data' | 'radar'>('dashboard');
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [state, setState] = useState<AppState>(initialState);

  // Handle account selection from dashboard or list
  const handleAccountSelect = (acc: Account) => {
    setSelectedAccount(acc);
    setView('accounts');
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col p-4">
        <div className="mb-10 px-2 pt-2">
          {LOGO}
        </div>
        
        <nav className="flex-1 space-y-1">
          <SidebarItem 
            icon={<LayoutDashboard className="w-5 h-5" />} 
            label="Dashboard" 
            active={view === 'dashboard' && !selectedAccount}
            onClick={() => { setView('dashboard'); setSelectedAccount(null); }}
          />
          <SidebarItem 
            icon={<Radar className="w-5 h-5" />} 
            label="Radar de Conflictos" 
            active={view === 'radar'}
            onClick={() => { setView('radar'); setSelectedAccount(null); }}
          />
          <SidebarItem 
            icon={<Users className="w-5 h-5" />} 
            label="Cuentas / Pipeline" 
            active={view === 'accounts' || selectedAccount !== null}
            onClick={() => { setView('accounts'); setSelectedAccount(null); }}
          />
          <SidebarItem 
            icon={<FileText className="w-5 h-5" />} 
            label="Importación de Datos" 
            active={view === 'data'}
            onClick={() => { setView('data'); setSelectedAccount(null); }}
          />
        </nav>

        <div className="mt-auto border-t border-slate-100 pt-4 px-2">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-600 text-xs">CR</div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-900 truncate">Carlos Revilla</p>
              <p className="text-[10px] text-slate-500 truncate">Arch. RevOps</p>
            </div>
            <Settings className="w-4 h-4 text-slate-400 cursor-pointer hover:text-slate-600" />
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-8 relative">
        <div className="max-w-6xl mx-auto">
          {selectedAccount ? (
            <AccountDetailView 
              account={selectedAccount} 
              state={state} 
              onBack={() => setSelectedAccount(null)} 
            />
          ) : (
            <>
              {view === 'dashboard' && <DashboardView state={state} onAccountSelect={handleAccountSelect} />}
              
              {view === 'radar' && (
                <div className="space-y-6 animate-in fade-in duration-500">
                  <header>
                    <h1 className="text-2xl font-bold text-slate-900">Radar Geográfico</h1>
                    <p className="text-slate-500">Visualización de criticidad por ubicación y severidad</p>
                  </header>
                  <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm overflow-hidden min-h-[500px] flex flex-col items-center justify-center text-center text-slate-400 space-y-4">
                    <Globe className="w-20 h-20 text-slate-100" />
                    <div>
                      <h4 className="text-lg font-bold text-slate-600">Mapa Interactivo de Conflictos</h4>
                      <p className="max-w-xs">Esta vista requiere integración con Mapbox/Google Maps API para renderizado en tiempo real de capas geoespaciales.</p>
                    </div>
                  </div>
                </div>
              )}

              {view === 'accounts' && (
                <div className="space-y-6 animate-in fade-in duration-500">
                  <header className="flex justify-between items-center">
                    <div>
                      <h1 className="text-2xl font-bold text-slate-900">Directorio de Cuentas</h1>
                      <p className="text-slate-500">Gestión centralizada del pipeline comercial</p>
                    </div>
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-md shadow-indigo-100">
                      <Plus className="w-4 h-4" /> Nueva Cuenta
                    </button>
                  </header>

                  <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-100">
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Empresa</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Región</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-center">Score</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Tier</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Etapa</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {state.accounts.map(acc => (
                          <tr 
                            key={acc.id} 
                            className="hover:bg-slate-50/50 cursor-pointer transition-colors group"
                            onClick={() => handleAccountSelect(acc)}
                          >
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded bg-indigo-50 flex items-center justify-center font-bold text-indigo-700 text-xs uppercase">
                                  {acc.nombreComercial.charAt(0)}
                                </div>
                                <span className="font-semibold text-slate-800 group-hover:text-indigo-600">{acc.nombreComercial}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-600">{acc.region}</td>
                            <td className="px-6 py-4 text-center">
                              <span className={`inline-block w-10 py-1 rounded-lg text-xs font-bold ${acc.scoreTotal > 80 ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'}`}>
                                {acc.scoreTotal}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <Badge variant={acc.tier === Tier.TIER1 ? 'amber' : 'slate'}>{acc.tier.split(' ')[1]}</Badge>
                            </td>
                            <td className="px-6 py-4">
                              <Badge variant="indigo">{acc.etapaPipeline}</Badge>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <ChevronRight className="w-4 h-4 text-slate-300 inline-block" />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {view === 'data' && <DataManagementView />}
            </>
          )}
        </div>
      </main>

      {/* Floating Action Button (Optional for Quick Tasks) */}
      <div className="fixed bottom-8 right-8">
        <button className="w-14 h-14 bg-indigo-600 rounded-full text-white shadow-2xl flex items-center justify-center hover:bg-indigo-700 hover:scale-105 transition-all active:scale-95 group relative">
          <BarChart3 className="w-6 h-6" />
          <span className="absolute right-full mr-3 px-2 py-1 bg-slate-800 text-white text-[10px] rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">Reporte Ejecutivo</span>
        </button>
      </div>
    </div>
  );
};

export default App;
