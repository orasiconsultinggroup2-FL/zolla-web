
export enum ConflictStatus {
  ACTIVO = 'Activo',
  LATENTE = 'Latente',
  DIALOGO = 'Diálogo',
  NO_DIALOGO = 'No Diálogo',
  OTRO = 'Otro'
}

export enum SignalSeverity {
  LOW = 1,
  MEDIUM_LOW = 2,
  MEDIUM = 3,
  MEDIUM_HIGH = 4,
  HIGH = 5
}

export enum Tier {
  TIER1 = 'Tier 1 (Prioritario)',
  TIER2 = 'Tier 2 (Estratégico)',
  TIER3 = 'Tier 3 (Monitoreo)'
}

export enum PipelineStage {
  DISCOVERY = 'Descubrimiento',
  PROSPECTING = 'Prospección',
  NURTURING = 'Nutrición',
  MEETING_SET = 'Reunión Agendada',
  PROPOSAL = 'Propuesta',
  CLOSED = 'Cerrado'
}

export interface Account {
  id: string;
  ruc?: string;
  razonSocial: string;
  nombreComercial: string;
  webOficial: string;
  centralTelOficial: string;
  correoInstitucional: string;
  sector: string;
  pais: string;
  region: string;
  proyectosUEA: string[];
  tamanoProxy: 'Grande' | 'Mediana' | 'Pequeña';
  ultimaActualizacion: string;
  owner: string;
  etapaPipeline: PipelineStage;
  scoreTotal: number;
  tier: Tier;
  proximaAccion?: string;
  fechaProximaAccion?: string;
}

export interface Case {
  id: string;
  accountId: string;
  nombreCaso: string;
  ubicacion: {
    dep: string;
    prov: string;
    dist: string;
  };
  tipoConflicto: string;
  estado: ConflictStatus;
  motivoResumen: string;
  fechaReporte: string;
  fuentePrimaria: string;
  urlFuente: string;
}

export interface Signal {
  id: string;
  accountId: string;
  tipo: 'Prensa' | 'Alerta' | 'Comunicado';
  severidad: SignalSeverity;
  fecha: string;
  resumen: string;
  url: string;
}

export interface Channel {
  id: string;
  accountId: string;
  tipo: 'Mesa de Partes' | 'Formulario' | 'Correo Central' | 'Central Telefónica' | 'LinkedIn Corporativo';
  detalle: string;
  url: string;
  verificado: boolean;
  fechaVerificacion: string;
}

export interface InteractionLog {
  id: string;
  accountId: string;
  fecha: string;
  accion: string;
  resultado: string;
  canal: string;
}

export interface AppState {
  accounts: Account[];
  cases: Case[];
  signals: Signal[];
  channels: Channel[];
  logs: InteractionLog[];
}
