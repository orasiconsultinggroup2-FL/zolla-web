
import { GoogleGenAI, Type } from "@google/genai";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeConflictInsight = async (caseDescription: string, companyName: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analiza el siguiente conflicto minero de la empresa ${companyName}: "${caseDescription}". 
      Genera una "Próxima Acción" comercial estratégica para una consultora que vende servicios de relaciones comunitarias. 
      Devuelve un JSON con: action (string), justification (string), y severity (1-5).`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING },
            justification: { type: Type.STRING },
            severity: { type: Type.NUMBER }
          },
          required: ["action", "justification", "severity"]
        }
      }
    });
    
    // The response.text property directly returns the generated text. Do not use text().
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};
